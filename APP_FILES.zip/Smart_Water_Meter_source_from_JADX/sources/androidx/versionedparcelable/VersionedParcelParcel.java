package androidx.versionedparcelable;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.util.SparseIntArray;

@RestrictTo({Scope.LIBRARY})
class VersionedParcelParcel extends VersionedParcel {
    private static final boolean DEBUG = false;
    private static final String TAG = "VersionedParcelParcel";
    private int mCurrentField;
    private final int mEnd;
    private int mNextRead;
    private final int mOffset;
    private final Parcel mParcel;
    private final SparseIntArray mPositionLookup;
    private final String mPrefix;

    VersionedParcelParcel(Parcel parcel) {
        Parcel p = parcel;
        this(p, p.dataPosition(), p.dataSize(), "");
    }

    VersionedParcelParcel(Parcel parcel, int i, int i2, String str) {
        SparseIntArray sparseIntArray;
        Parcel p = parcel;
        int offset = i;
        int end = i2;
        String prefix = str;
        SparseIntArray sparseIntArray2 = sparseIntArray;
        SparseIntArray sparseIntArray3 = new SparseIntArray();
        this.mPositionLookup = sparseIntArray2;
        this.mCurrentField = -1;
        this.mNextRead = 0;
        this.mParcel = p;
        this.mOffset = offset;
        this.mEnd = end;
        this.mNextRead = this.mOffset;
        this.mPrefix = prefix;
    }

    private int readUntilField(int i) {
        int fieldId = i;
        while (this.mNextRead < this.mEnd) {
            this.mParcel.setDataPosition(this.mNextRead);
            int size = this.mParcel.readInt();
            int fid = this.mParcel.readInt();
            this.mNextRead += size;
            if (fid == fieldId) {
                return this.mParcel.dataPosition();
            }
        }
        return -1;
    }

    public boolean readField(int i) {
        int position = readUntilField(i);
        if (position == -1) {
            return false;
        }
        this.mParcel.setDataPosition(position);
        return true;
    }

    public void setOutputField(int i) {
        int fieldId = i;
        closeField();
        this.mCurrentField = fieldId;
        this.mPositionLookup.put(fieldId, this.mParcel.dataPosition());
        writeInt(0);
        writeInt(fieldId);
    }

    public void closeField() {
        if (this.mCurrentField >= 0) {
            int currentFieldPosition = this.mPositionLookup.get(this.mCurrentField);
            int position = this.mParcel.dataPosition();
            int size = position - currentFieldPosition;
            this.mParcel.setDataPosition(currentFieldPosition);
            this.mParcel.writeInt(size);
            this.mParcel.setDataPosition(position);
        }
    }

    /* access modifiers changed from: protected */
    public VersionedParcel createSubParcel() {
        StringBuilder sb;
        VersionedParcelParcel versionedParcelParcel = r2;
        VersionedParcelParcel versionedParcelParcel2 = versionedParcelParcel;
        r2 = versionedParcelParcel;
        Parcel parcel = this.mParcel;
        int dataPosition = this.mParcel.dataPosition();
        int i = this.mNextRead == this.mOffset ? this.mEnd : this.mNextRead;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        VersionedParcelParcel versionedParcelParcel3 = new VersionedParcelParcel(parcel, dataPosition, i, sb2.append(this.mPrefix).append("  ").toString());
        return versionedParcelParcel2;
    }

    public void writeByteArray(byte[] bArr) {
        byte[] b = bArr;
        if (b != null) {
            this.mParcel.writeInt(b.length);
            this.mParcel.writeByteArray(b);
            return;
        }
        this.mParcel.writeInt(-1);
    }

    public void writeByteArray(byte[] bArr, int i, int i2) {
        byte[] b = bArr;
        int offset = i;
        int len = i2;
        if (b != null) {
            this.mParcel.writeInt(b.length);
            this.mParcel.writeByteArray(b, offset, len);
            return;
        }
        this.mParcel.writeInt(-1);
    }

    public void writeInt(int i) {
        int val = i;
        this.mParcel.writeInt(val);
    }

    public void writeLong(long j) {
        long val = j;
        this.mParcel.writeLong(val);
    }

    public void writeFloat(float f) {
        float val = f;
        this.mParcel.writeFloat(val);
    }

    public void writeDouble(double d) {
        double val = d;
        this.mParcel.writeDouble(val);
    }

    public void writeString(String str) {
        String val = str;
        this.mParcel.writeString(val);
    }

    public void writeStrongBinder(IBinder iBinder) {
        IBinder val = iBinder;
        this.mParcel.writeStrongBinder(val);
    }

    public void writeParcelable(Parcelable parcelable) {
        Parcelable p = parcelable;
        this.mParcel.writeParcelable(p, 0);
    }

    public void writeBoolean(boolean z) {
        this.mParcel.writeInt(z ? 1 : 0);
    }

    public void writeStrongInterface(IInterface iInterface) {
        IInterface val = iInterface;
        this.mParcel.writeStrongInterface(val);
    }

    public void writeBundle(Bundle bundle) {
        Bundle val = bundle;
        this.mParcel.writeBundle(val);
    }

    public int readInt() {
        return this.mParcel.readInt();
    }

    public long readLong() {
        return this.mParcel.readLong();
    }

    public float readFloat() {
        return this.mParcel.readFloat();
    }

    public double readDouble() {
        return this.mParcel.readDouble();
    }

    public String readString() {
        return this.mParcel.readString();
    }

    public IBinder readStrongBinder() {
        return this.mParcel.readStrongBinder();
    }

    public byte[] readByteArray() {
        int len = this.mParcel.readInt();
        if (len < 0) {
            return null;
        }
        byte[] bytes = new byte[len];
        this.mParcel.readByteArray(bytes);
        return bytes;
    }

    public <T extends Parcelable> T readParcelable() {
        return this.mParcel.readParcelable(getClass().getClassLoader());
    }

    public Bundle readBundle() {
        return this.mParcel.readBundle(getClass().getClassLoader());
    }

    public boolean readBoolean() {
        return this.mParcel.readInt() != 0;
    }
}
