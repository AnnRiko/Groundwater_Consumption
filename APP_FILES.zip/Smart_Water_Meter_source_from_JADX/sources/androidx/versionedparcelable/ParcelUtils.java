package androidx.versionedparcelable;

import android.os.Parcelable;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import java.io.InputStream;
import java.io.OutputStream;

@RestrictTo({Scope.LIBRARY_GROUP})
public class ParcelUtils {
    private ParcelUtils() {
    }

    public static Parcelable toParcelable(VersionedParcelable versionedParcelable) {
        ParcelImpl parcelImpl;
        ParcelImpl parcelImpl2 = parcelImpl;
        ParcelImpl parcelImpl3 = new ParcelImpl(versionedParcelable);
        return parcelImpl2;
    }

    public static <T extends VersionedParcelable> T fromParcelable(Parcelable parcelable) {
        IllegalArgumentException illegalArgumentException;
        Parcelable p = parcelable;
        if (p instanceof ParcelImpl) {
            return ((ParcelImpl) p).getVersionedParcel();
        }
        IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
        IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("Invalid parcel");
        throw illegalArgumentException2;
    }

    public static void toOutputStream(VersionedParcelable versionedParcelable, OutputStream outputStream) {
        VersionedParcelStream versionedParcelStream;
        VersionedParcelable obj = versionedParcelable;
        VersionedParcelStream versionedParcelStream2 = versionedParcelStream;
        VersionedParcelStream versionedParcelStream3 = new VersionedParcelStream(null, outputStream);
        VersionedParcelStream stream = versionedParcelStream2;
        stream.writeVersionedParcelable(obj);
        stream.closeField();
    }

    public static <T extends VersionedParcelable> T fromInputStream(InputStream inputStream) {
        VersionedParcelStream versionedParcelStream;
        VersionedParcelStream versionedParcelStream2 = versionedParcelStream;
        VersionedParcelStream versionedParcelStream3 = new VersionedParcelStream(inputStream, null);
        return versionedParcelStream2.readVersionedParcelable();
    }
}
