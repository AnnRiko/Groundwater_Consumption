package android.support.constraint.solver.widgets;

import android.support.constraint.solver.LinearSystem;

class Chain {
    private static final boolean DEBUG = false;

    Chain() {
    }

    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i) {
        int offset;
        int chainsSize;
        ChainHead[] chainsArray;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        LinearSystem system = linearSystem;
        int orientation = i;
        if (orientation == 0) {
            offset = 0;
            chainsSize = constraintWidgetContainer2.mHorizontalChainsSize;
            chainsArray = constraintWidgetContainer2.mHorizontalChainsArray;
        } else {
            offset = 2;
            chainsSize = constraintWidgetContainer2.mVerticalChainsSize;
            chainsArray = constraintWidgetContainer2.mVerticalChainsArray;
        }
        for (int i2 = 0; i2 < chainsSize; i2++) {
            ChainHead first = chainsArray[i2];
            first.define();
            if (!constraintWidgetContainer2.optimizeFor(4)) {
                applyChainConstraints(constraintWidgetContainer2, system, orientation, offset, first);
            } else if (!Optimizer.applyChainOptimized(constraintWidgetContainer2, system, orientation, offset, first)) {
                applyChainConstraints(constraintWidgetContainer2, system, orientation, offset, first);
            }
        }
    }

    /* JADX WARNING: type inference failed for: r36v5 */
    /* JADX WARNING: type inference failed for: r36v7 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 2 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void applyChainConstraints(android.support.constraint.solver.widgets.ConstraintWidgetContainer r45, android.support.constraint.solver.LinearSystem r46, int r47, int r48, android.support.constraint.solver.widgets.ChainHead r49) {
        /*
            r2 = r45
            r3 = r46
            r4 = r47
            r5 = r48
            r6 = r49
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mFirst
            r36 = r0
            r7 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mLast
            r36 = r0
            r8 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mFirstVisibleWidget
            r36 = r0
            r9 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mLastVisibleWidget
            r36 = r0
            r10 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mHead
            r36 = r0
            r11 = r36
            r36 = r7
            r12 = r36
            r36 = 0
            r13 = r36
            r36 = 0
            r14 = r36
            r36 = r6
            r0 = r36
            float r0 = r0.mTotalWeight
            r36 = r0
            r15 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mFirstMatchConstraintWidget
            r36 = r0
            r16 = r36
            r36 = r6
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mLastMatchConstraintWidget
            r36 = r0
            r17 = r36
            r36 = r2
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r0 = r0.mListDimensionBehaviors
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r37 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.WRAP_CONTENT
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x026f
            r36 = 1
        L_0x007c:
            r18 = r36
            r36 = 0
            r19 = r36
            r36 = 0
            r20 = r36
            r36 = 0
            r21 = r36
            r36 = r4
            if (r36 != 0) goto L_0x027f
            r36 = r11
            r0 = r36
            int r0 = r0.mHorizontalChainStyle
            r36 = r0
            if (r36 != 0) goto L_0x0273
            r36 = 1
        L_0x009a:
            r19 = r36
            r36 = r11
            r0 = r36
            int r0 = r0.mHorizontalChainStyle
            r36 = r0
            r37 = 1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0277
            r36 = 1
        L_0x00ae:
            r20 = r36
            r36 = r11
            r0 = r36
            int r0 = r0.mHorizontalChainStyle
            r36 = r0
            r37 = 2
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x027b
            r36 = 1
        L_0x00c2:
            r21 = r36
        L_0x00c4:
            r36 = r14
            if (r36 != 0) goto L_0x02fb
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r22 = r36
            r36 = 4
            r23 = r36
            r36 = r18
            if (r36 != 0) goto L_0x00e2
            r36 = r21
            if (r36 == 0) goto L_0x00e6
        L_0x00e2:
            r36 = 1
            r23 = r36
        L_0x00e6:
            r36 = r22
            int r36 = r36.getMargin()
            r24 = r36
            r36 = r22
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0114
            r36 = r12
            r37 = r7
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0114
            r36 = r24
            r37 = r22
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r37 = r0
            int r37 = r37.getMargin()
            int r36 = r36 + r37
            r24 = r36
        L_0x0114:
            r36 = r21
            if (r36 == 0) goto L_0x02c0
            r36 = r12
            r37 = r7
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x02c0
            r36 = r12
            r37 = r9
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x02c0
            r36 = 6
            r23 = r36
        L_0x0130:
            r36 = r22
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0183
            r36 = r12
            r37 = r9
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x02ce
            r36 = r3
            r37 = r22
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r22
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r38 = r0
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r24
            r40 = 5
            r36.addGreaterThan(r37, r38, r39, r40)
        L_0x0163:
            r36 = r3
            r37 = r22
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r22
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r38 = r0
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r24
            r40 = r23
            android.support.constraint.solver.ArrayRow r36 = r36.addEquality(r37, r38, r39, r40)
        L_0x0183:
            r36 = r18
            if (r36 == 0) goto L_0x0207
            r36 = r12
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x01da
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour[] r0 = r0.mListDimensionBehaviors
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            android.support.constraint.solver.widgets.ConstraintWidget$DimensionBehaviour r37 = android.support.constraint.solver.widgets.ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x01da
            r36 = r3
            r37 = r12
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r12
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = 0
            r40 = 5
            r36.addGreaterThan(r37, r38, r39, r40)
        L_0x01da:
            r36 = r3
            r37 = r12
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r37 = r37[r38]
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r2
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = 0
            r40 = 6
            r36.addGreaterThan(r37, r38, r39, r40)
        L_0x0207:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r25 = r36
            r36 = r25
            if (r36 == 0) goto L_0x02ef
            r36 = r25
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            r36 = r0
            r13 = r36
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0261
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget r0 = r0.mOwner
            r36 = r0
            r37 = r12
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0265
        L_0x0261:
            r36 = 0
            r13 = r36
        L_0x0265:
            r36 = r13
            if (r36 == 0) goto L_0x02f5
            r36 = r13
            r12 = r36
        L_0x026d:
            goto L_0x00c4
        L_0x026f:
            r36 = 0
            goto L_0x007c
        L_0x0273:
            r36 = 0
            goto L_0x009a
        L_0x0277:
            r36 = 0
            goto L_0x00ae
        L_0x027b:
            r36 = 0
            goto L_0x00c2
        L_0x027f:
            r36 = r11
            r0 = r36
            int r0 = r0.mVerticalChainStyle
            r36 = r0
            if (r36 != 0) goto L_0x02b7
            r36 = 1
        L_0x028b:
            r19 = r36
            r36 = r11
            r0 = r36
            int r0 = r0.mVerticalChainStyle
            r36 = r0
            r37 = 1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x02ba
            r36 = 1
        L_0x029f:
            r20 = r36
            r36 = r11
            r0 = r36
            int r0 = r0.mVerticalChainStyle
            r36 = r0
            r37 = 2
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x02bd
            r36 = 1
        L_0x02b3:
            r21 = r36
            goto L_0x00c4
        L_0x02b7:
            r36 = 0
            goto L_0x028b
        L_0x02ba:
            r36 = 0
            goto L_0x029f
        L_0x02bd:
            r36 = 0
            goto L_0x02b3
        L_0x02c0:
            r36 = r19
            if (r36 == 0) goto L_0x0130
            r36 = r18
            if (r36 == 0) goto L_0x0130
            r36 = 4
            r23 = r36
            goto L_0x0130
        L_0x02ce:
            r36 = r3
            r37 = r22
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r22
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r38 = r0
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r24
            r40 = 6
            r36.addGreaterThan(r37, r38, r39, r40)
            goto L_0x0163
        L_0x02ef:
            r36 = 0
            r13 = r36
            goto L_0x0265
        L_0x02f5:
            r36 = 1
            r14 = r36
            goto L_0x026d
        L_0x02fb:
            r36 = r10
            if (r36 == 0) goto L_0x035f
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x035f
            r36 = r10
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r22 = r36
            r36 = r3
            r37 = r22
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r8
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r40 = 1
            int r39 = r39 + 1
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r38 = r0
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r22
            int r39 = r39.getMargin()
            r0 = r39
            int r0 = -r0
            r39 = r0
            r40 = 5
            r36.addLowerThan(r37, r38, r39, r40)
        L_0x035f:
            r36 = r18
            if (r36 == 0) goto L_0x03aa
            r36 = r3
            r37 = r2
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r8
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r40 = 1
            int r39 = r39 + 1
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r8
            r0 = r39
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r39 = r0
            r40 = r5
            r41 = 1
            int r40 = r40 + 1
            r39 = r39[r40]
            int r39 = r39.getMargin()
            r40 = 6
            r36.addGreaterThan(r37, r38, r39, r40)
        L_0x03aa:
            r36 = r6
            r0 = r36
            java.util.ArrayList<android.support.constraint.solver.widgets.ConstraintWidget> r0 = r0.mWeightedMatchConstraintsWidgets
            r36 = r0
            r22 = r36
            r36 = r22
            if (r36 == 0) goto L_0x052c
            r36 = r22
            int r36 = r36.size()
            r23 = r36
            r36 = r23
            r37 = 1
            r0 = r36
            r1 = r37
            if (r0 <= r1) goto L_0x052c
            r36 = 0
            r24 = r36
            r36 = 0
            r25 = r36
            r36 = r6
            r0 = r36
            boolean r0 = r0.mHasUndefinedWeights
            r36 = r0
            if (r36 == 0) goto L_0x03f5
            r36 = r6
            r0 = r36
            boolean r0 = r0.mHasComplexMatchWeights
            r36 = r0
            if (r36 != 0) goto L_0x03f5
            r36 = r6
            r0 = r36
            int r0 = r0.mWidgetsMatchCount
            r36 = r0
            r0 = r36
            float r0 = (float) r0
            r36 = r0
            r15 = r36
        L_0x03f5:
            r36 = 0
            r26 = r36
        L_0x03f9:
            r36 = r26
            r37 = r23
            r0 = r36
            r1 = r37
            if (r0 >= r1) goto L_0x052c
            r36 = r22
            r37 = r26
            java.lang.Object r36 = r36.get(r37)
            android.support.constraint.solver.widgets.ConstraintWidget r36 = (android.support.constraint.solver.widgets.ConstraintWidget) r36
            r27 = r36
            r36 = r27
            r0 = r36
            float[] r0 = r0.mWeight
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            r28 = r36
            r36 = r28
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 >= 0) goto L_0x0468
            r36 = r6
            r0 = r36
            boolean r0 = r0.mHasComplexMatchWeights
            r36 = r0
            if (r36 == 0) goto L_0x0464
            r36 = r3
            r37 = r27
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r27
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = 0
            r40 = 4
            android.support.constraint.solver.ArrayRow r36 = r36.addEquality(r37, r38, r39, r40)
        L_0x0461:
            int r26 = r26 + 1
            goto L_0x03f9
        L_0x0464:
            r36 = 1065353216(0x3f800000, float:1.0)
            r28 = r36
        L_0x0468:
            r36 = r28
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 != 0) goto L_0x04a3
            r36 = r3
            r37 = r27
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r27
            r0 = r38
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r38 = r0
            r39 = r5
            r38 = r38[r39]
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = 0
            r40 = 6
            android.support.constraint.solver.ArrayRow r36 = r36.addEquality(r37, r38, r39, r40)
            goto L_0x0461
        L_0x04a3:
            r36 = r24
            if (r36 == 0) goto L_0x0522
            r36 = r24
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r29 = r36
            r36 = r24
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r30 = r36
            r36 = r27
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r31 = r36
            r36 = r27
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r32 = r36
            r36 = r3
            android.support.constraint.solver.ArrayRow r36 = r36.createRow()
            r33 = r36
            r36 = r33
            r37 = r25
            r38 = r15
            r39 = r28
            r40 = r29
            r41 = r30
            r42 = r31
            r43 = r32
            android.support.constraint.solver.ArrayRow r36 = r36.createRowEqualMatchDimensions(r37, r38, r39, r40, r41, r42, r43)
            r36 = r3
            r37 = r33
            r36.addConstraint(r37)
        L_0x0522:
            r36 = r27
            r24 = r36
            r36 = r28
            r25 = r36
            goto L_0x0461
        L_0x052c:
            r36 = r9
            if (r36 == 0) goto L_0x075f
            r36 = r9
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x053e
            r36 = r21
            if (r36 == 0) goto L_0x075f
        L_0x053e:
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r23 = r36
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r24 = r36
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x074b
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x058a:
            r25 = r36
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x074f
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x05c0:
            r26 = r36
            r36 = r9
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x05ec
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r23 = r36
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r24 = r36
        L_0x05ec:
            r36 = r25
            if (r36 == 0) goto L_0x0637
            r36 = r26
            if (r36 == 0) goto L_0x0637
            r36 = 1056964608(0x3f000000, float:0.5)
            r27 = r36
            r36 = r4
            if (r36 != 0) goto L_0x0753
            r36 = r11
            r0 = r36
            float r0 = r0.mHorizontalBiasPercent
            r36 = r0
            r27 = r36
        L_0x0606:
            r36 = r23
            int r36 = r36.getMargin()
            r28 = r36
            r36 = r24
            int r36 = r36.getMargin()
            r29 = r36
            r36 = r3
            r37 = r23
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r25
            r39 = r28
            r40 = r27
            r41 = r26
            r42 = r24
            r0 = r42
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r42 = r0
            r43 = r29
            r44 = 5
            r36.addCentering(r37, r38, r39, r40, r41, r42, r43, r44)
        L_0x0637:
            r36 = r19
            if (r36 != 0) goto L_0x063f
            r36 = r20
            if (r36 == 0) goto L_0x074a
        L_0x063f:
            r36 = r9
            if (r36 == 0) goto L_0x074a
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r23 = r36
            r36 = r10
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r24 = r36
            r36 = r23
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0cae
            r36 = r23
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x067b:
            r25 = r36
            r36 = r24
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0cb2
            r36 = r24
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x0695:
            r26 = r36
            r36 = r8
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x06cd
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r27 = r36
            r36 = r27
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0cb6
            r36 = r27
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x06cb:
            r26 = r36
        L_0x06cd:
            r36 = r9
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x06f7
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r23 = r36
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r24 = r36
        L_0x06f7:
            r36 = r25
            if (r36 == 0) goto L_0x074a
            r36 = r26
            if (r36 == 0) goto L_0x074a
            r36 = 1056964608(0x3f000000, float:0.5)
            r27 = r36
            r36 = r23
            int r36 = r36.getMargin()
            r28 = r36
            r36 = r10
            if (r36 != 0) goto L_0x0713
            r36 = r8
            r10 = r36
        L_0x0713:
            r36 = r10
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            int r36 = r36.getMargin()
            r29 = r36
            r36 = r3
            r37 = r23
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r25
            r39 = r28
            r40 = r27
            r41 = r26
            r42 = r24
            r0 = r42
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r42 = r0
            r43 = r29
            r44 = 5
            r36.addCentering(r37, r38, r39, r40, r41, r42, r43, r44)
        L_0x074a:
            return
        L_0x074b:
            r36 = 0
            goto L_0x058a
        L_0x074f:
            r36 = 0
            goto L_0x05c0
        L_0x0753:
            r36 = r11
            r0 = r36
            float r0 = r0.mVerticalBiasPercent
            r36 = r0
            r27 = r36
            goto L_0x0606
        L_0x075f:
            r36 = r19
            if (r36 == 0) goto L_0x09d1
            r36 = r9
            if (r36 == 0) goto L_0x09d1
            r36 = r9
            r12 = r36
            r36 = r9
            r23 = r36
            r36 = r6
            r0 = r36
            int r0 = r0.mWidgetsMatchCount
            r36 = r0
            if (r36 <= 0) goto L_0x07c6
            r36 = r6
            r0 = r36
            int r0 = r0.mWidgetsCount
            r36 = r0
            r37 = r6
            r0 = r37
            int r0 = r0.mWidgetsMatchCount
            r37 = r0
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x07c6
            r36 = 1
        L_0x0791:
            r24 = r36
        L_0x0793:
            r36 = r12
            if (r36 == 0) goto L_0x09cf
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget[] r0 = r0.mNextChainWidget
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            r13 = r36
        L_0x07a5:
            r36 = r13
            if (r36 == 0) goto L_0x07c9
            r36 = r13
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x07c9
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget[] r0 = r0.mNextChainWidget
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            r13 = r36
            goto L_0x07a5
        L_0x07c6:
            r36 = 0
            goto L_0x0791
        L_0x07c9:
            r36 = r13
            if (r36 != 0) goto L_0x07d7
            r36 = r12
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x092c
        L_0x07d7:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r25 = r36
            r36 = r25
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r26 = r36
            r36 = r25
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0944
            r36 = r25
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x0807:
            r27 = r36
            r36 = r23
            r37 = r12
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0948
            r36 = r23
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r27 = r36
        L_0x082b:
            r36 = 0
            r28 = r36
            r36 = 0
            r29 = r36
            r36 = 0
            r30 = r36
            r36 = r25
            int r36 = r36.getMargin()
            r31 = r36
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            int r36 = r36.getMargin()
            r32 = r36
            r36 = r13
            if (r36 == 0) goto L_0x098f
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r28 = r36
            r36 = r28
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r29 = r36
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r30 = r36
        L_0x0889:
            r36 = r28
            if (r36 == 0) goto L_0x0899
            r36 = r32
            r37 = r28
            int r37 = r37.getMargin()
            int r36 = r36 + r37
            r32 = r36
        L_0x0899:
            r36 = r23
            if (r36 == 0) goto L_0x08b7
            r36 = r31
            r37 = r23
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            int r37 = r37.getMargin()
            int r36 = r36 + r37
            r31 = r36
        L_0x08b7:
            r36 = r26
            if (r36 == 0) goto L_0x092c
            r36 = r27
            if (r36 == 0) goto L_0x092c
            r36 = r29
            if (r36 == 0) goto L_0x092c
            r36 = r30
            if (r36 == 0) goto L_0x092c
            r36 = r31
            r33 = r36
            r36 = r12
            r37 = r9
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x08e7
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            int r36 = r36.getMargin()
            r33 = r36
        L_0x08e7:
            r36 = r32
            r34 = r36
            r36 = r12
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x090b
            r36 = r10
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            int r36 = r36.getMargin()
            r34 = r36
        L_0x090b:
            r36 = 4
            r35 = r36
            r36 = r24
            if (r36 == 0) goto L_0x0917
            r36 = 6
            r35 = r36
        L_0x0917:
            r36 = r3
            r37 = r26
            r38 = r27
            r39 = r33
            r40 = 1056964608(0x3f000000, float:0.5)
            r41 = r29
            r42 = r30
            r43 = r34
            r44 = r35
            r36.addCentering(r37, r38, r39, r40, r41, r42, r43, r44)
        L_0x092c:
            r36 = r12
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x093e
            r36 = r12
            r23 = r36
        L_0x093e:
            r36 = r13
            r12 = r36
            goto L_0x0793
        L_0x0944:
            r36 = 0
            goto L_0x0807
        L_0x0948:
            r36 = r12
            r37 = r9
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x082b
            r36 = r23
            r37 = r12
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x082b
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x098c
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x0988:
            r27 = r36
            goto L_0x082b
        L_0x098c:
            r36 = 0
            goto L_0x0988
        L_0x098f:
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r28 = r36
            r36 = r28
            if (r36 == 0) goto L_0x09b5
            r36 = r28
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r29 = r36
        L_0x09b5:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r30 = r36
            goto L_0x0889
        L_0x09cf:
            goto L_0x0637
        L_0x09d1:
            r36 = r20
            if (r36 == 0) goto L_0x0637
            r36 = r9
            if (r36 == 0) goto L_0x0637
            r36 = r9
            r12 = r36
            r36 = r9
            r23 = r36
            r36 = r6
            r0 = r36
            int r0 = r0.mWidgetsMatchCount
            r36 = r0
            if (r36 <= 0) goto L_0x0a38
            r36 = r6
            r0 = r36
            int r0 = r0.mWidgetsCount
            r36 = r0
            r37 = r6
            r0 = r37
            int r0 = r0.mWidgetsMatchCount
            r37 = r0
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a38
            r36 = 1
        L_0x0a03:
            r24 = r36
        L_0x0a05:
            r36 = r12
            if (r36 == 0) goto L_0x0bc9
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget[] r0 = r0.mNextChainWidget
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            r13 = r36
        L_0x0a17:
            r36 = r13
            if (r36 == 0) goto L_0x0a3b
            r36 = r13
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a3b
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintWidget[] r0 = r0.mNextChainWidget
            r36 = r0
            r37 = r4
            r36 = r36[r37]
            r13 = r36
            goto L_0x0a17
        L_0x0a38:
            r36 = 0
            goto L_0x0a03
        L_0x0a3b:
            r36 = r12
            r37 = r9
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0b6a
            r36 = r12
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0b6a
            r36 = r13
            if (r36 == 0) goto L_0x0b6a
            r36 = r13
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a61
            r36 = 0
            r13 = r36
        L_0x0a61:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r25 = r36
            r36 = r25
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r26 = r36
            r36 = r25
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0b82
            r36 = r25
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x0a91:
            r27 = r36
            r36 = r23
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r27 = r36
            r36 = 0
            r28 = r36
            r36 = 0
            r29 = r36
            r36 = 0
            r30 = r36
            r36 = r25
            int r36 = r36.getMargin()
            r31 = r36
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            int r36 = r36.getMargin()
            r32 = r36
            r36 = r13
            if (r36 == 0) goto L_0x0b89
            r36 = r13
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r28 = r36
            r36 = r28
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r29 = r36
            r36 = r28
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            if (r36 == 0) goto L_0x0b86
            r36 = r28
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
        L_0x0b09:
            r30 = r36
        L_0x0b0b:
            r36 = r28
            if (r36 == 0) goto L_0x0b1b
            r36 = r32
            r37 = r28
            int r37 = r37.getMargin()
            int r36 = r36 + r37
            r32 = r36
        L_0x0b1b:
            r36 = r23
            if (r36 == 0) goto L_0x0b39
            r36 = r31
            r37 = r23
            r0 = r37
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r37 = r0
            r38 = r5
            r39 = 1
            int r38 = r38 + 1
            r37 = r37[r38]
            int r37 = r37.getMargin()
            int r36 = r36 + r37
            r31 = r36
        L_0x0b39:
            r36 = 4
            r33 = r36
            r36 = r24
            if (r36 == 0) goto L_0x0b45
            r36 = 6
            r33 = r36
        L_0x0b45:
            r36 = r26
            if (r36 == 0) goto L_0x0b6a
            r36 = r27
            if (r36 == 0) goto L_0x0b6a
            r36 = r29
            if (r36 == 0) goto L_0x0b6a
            r36 = r30
            if (r36 == 0) goto L_0x0b6a
            r36 = r3
            r37 = r26
            r38 = r27
            r39 = r31
            r40 = 1056964608(0x3f000000, float:0.5)
            r41 = r29
            r42 = r30
            r43 = r32
            r44 = r33
            r36.addCentering(r37, r38, r39, r40, r41, r42, r43, r44)
        L_0x0b6a:
            r36 = r12
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0b7c
            r36 = r12
            r23 = r36
        L_0x0b7c:
            r36 = r13
            r12 = r36
            goto L_0x0a05
        L_0x0b82:
            r36 = 0
            goto L_0x0a91
        L_0x0b86:
            r36 = 0
            goto L_0x0b09
        L_0x0b89:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r28 = r36
            r36 = r28
            if (r36 == 0) goto L_0x0baf
            r36 = r28
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r29 = r36
        L_0x0baf:
            r36 = r12
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r36 = r0
            r30 = r36
            goto L_0x0b0b
        L_0x0bc9:
            r36 = r9
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r25 = r36
            r36 = r7
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r26 = r36
            r36 = r10
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r27 = r36
            r36 = r8
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor[] r0 = r0.mListAnchors
            r36 = r0
            r37 = r5
            r38 = 1
            int r37 = r37 + 1
            r36 = r36[r37]
            r0 = r36
            android.support.constraint.solver.widgets.ConstraintAnchor r0 = r0.mTarget
            r36 = r0
            r28 = r36
            r36 = r26
            if (r36 == 0) goto L_0x0c41
            r36 = r9
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0c74
            r36 = r3
            r37 = r25
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r26
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r25
            int r39 = r39.getMargin()
            r40 = 5
            android.support.constraint.solver.ArrayRow r36 = r36.addEquality(r37, r38, r39, r40)
        L_0x0c41:
            r36 = r28
            if (r36 == 0) goto L_0x0637
            r36 = r9
            r37 = r10
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0637
            r36 = r3
            r37 = r27
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r28
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r27
            int r39 = r39.getMargin()
            r0 = r39
            int r0 = -r0
            r39 = r0
            r40 = 5
            android.support.constraint.solver.ArrayRow r36 = r36.addEquality(r37, r38, r39, r40)
            goto L_0x0637
        L_0x0c74:
            r36 = r28
            if (r36 == 0) goto L_0x0c41
            r36 = r3
            r37 = r25
            r0 = r37
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r37 = r0
            r38 = r26
            r0 = r38
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r38 = r0
            r39 = r25
            int r39 = r39.getMargin()
            r40 = 1056964608(0x3f000000, float:0.5)
            r41 = r27
            r0 = r41
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r41 = r0
            r42 = r28
            r0 = r42
            android.support.constraint.solver.SolverVariable r0 = r0.mSolverVariable
            r42 = r0
            r43 = r27
            int r43 = r43.getMargin()
            r44 = 5
            r36.addCentering(r37, r38, r39, r40, r41, r42, r43, r44)
            goto L_0x0c41
        L_0x0cae:
            r36 = 0
            goto L_0x067b
        L_0x0cb2:
            r36 = 0
            goto L_0x0695
        L_0x0cb6:
            r36 = 0
            goto L_0x06cb
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.Chain.applyChainConstraints(android.support.constraint.solver.widgets.ConstraintWidgetContainer, android.support.constraint.solver.LinearSystem, int, int, android.support.constraint.solver.widgets.ChainHead):void");
    }
}
