package android.support.constraint.solver.widgets;

import android.support.constraint.solver.Cache;
import java.util.ArrayList;

public class WidgetContainer extends ConstraintWidget {
    protected ArrayList<ConstraintWidget> mChildren;

    public WidgetContainer() {
        ArrayList<ConstraintWidget> arrayList;
        ArrayList<ConstraintWidget> arrayList2 = arrayList;
        ArrayList<ConstraintWidget> arrayList3 = new ArrayList<>();
        this.mChildren = arrayList2;
    }

    public WidgetContainer(int i, int i2, int i3, int i4) {
        ArrayList<ConstraintWidget> arrayList;
        super(i, i2, i3, i4);
        ArrayList<ConstraintWidget> arrayList2 = arrayList;
        ArrayList<ConstraintWidget> arrayList3 = new ArrayList<>();
        this.mChildren = arrayList2;
    }

    public WidgetContainer(int i, int i2) {
        ArrayList<ConstraintWidget> arrayList;
        super(i, i2);
        ArrayList<ConstraintWidget> arrayList2 = arrayList;
        ArrayList<ConstraintWidget> arrayList3 = new ArrayList<>();
        this.mChildren = arrayList2;
    }

    public void reset() {
        this.mChildren.clear();
        super.reset();
    }

    public void add(ConstraintWidget constraintWidget) {
        ConstraintWidget widget = constraintWidget;
        boolean add = this.mChildren.add(widget);
        if (widget.getParent() != null) {
            ((WidgetContainer) widget.getParent()).remove(widget);
        }
        widget.setParent(this);
    }

    public void add(ConstraintWidget... constraintWidgetArr) {
        ConstraintWidget[] widgets = constraintWidgetArr;
        int count = widgets.length;
        for (int i = 0; i < count; i++) {
            add(widgets[i]);
        }
    }

    public void remove(ConstraintWidget constraintWidget) {
        ConstraintWidget widget = constraintWidget;
        boolean remove = this.mChildren.remove(widget);
        widget.setParent(null);
    }

    public ArrayList<ConstraintWidget> getChildren() {
        return this.mChildren;
    }

    public ConstraintWidgetContainer getRootConstraintContainer() {
        ConstraintWidget parent = getParent();
        ConstraintWidgetContainer container = null;
        if (this instanceof ConstraintWidgetContainer) {
            container = (ConstraintWidgetContainer) this;
        }
        while (parent != null) {
            ConstraintWidget item = parent;
            parent = item.getParent();
            if (item instanceof ConstraintWidgetContainer) {
                container = (ConstraintWidgetContainer) item;
            }
        }
        return container;
    }

    /* JADX WARNING: type inference failed for: r12v20, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r10v0 */
    /* JADX WARNING: type inference failed for: r12v21 */
    /* JADX WARNING: type inference failed for: r12v23, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r12v25, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r13v8, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r13v10, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r12v39 */
    /* JADX WARNING: type inference failed for: r3v3 */
    /* JADX WARNING: type inference failed for: r12v40 */
    /* JADX WARNING: type inference failed for: r12v42, types: [android.support.constraint.solver.widgets.ConstraintWidget] */
    /* JADX WARNING: type inference failed for: r11v0 */
    /* JADX WARNING: type inference failed for: r12v43 */
    /* JADX WARNING: type inference failed for: r12v44 */
    /* JADX WARNING: type inference failed for: r3v5 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 13 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.support.constraint.solver.widgets.ConstraintWidget findWidget(float r16, float r17) {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r2 = r17
            r12 = 0
            r3 = r12
            r12 = r0
            int r12 = r12.getDrawX()
            r4 = r12
            r12 = r0
            int r12 = r12.getDrawY()
            r5 = r12
            r12 = r4
            r13 = r0
            int r13 = r13.getWidth()
            int r12 = r12 + r13
            r6 = r12
            r12 = r5
            r13 = r0
            int r13 = r13.getHeight()
            int r12 = r12 + r13
            r7 = r12
            r12 = r1
            r13 = r4
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 < 0) goto L_0x0041
            r12 = r1
            r13 = r6
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 > 0) goto L_0x0041
            r12 = r2
            r13 = r5
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 < 0) goto L_0x0041
            r12 = r2
            r13 = r7
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 > 0) goto L_0x0041
            r12 = r0
            r3 = r12
        L_0x0041:
            r12 = 0
            r8 = r12
            r12 = r0
            java.util.ArrayList<android.support.constraint.solver.widgets.ConstraintWidget> r12 = r12.mChildren
            int r12 = r12.size()
            r9 = r12
        L_0x004b:
            r12 = r8
            r13 = r9
            if (r12 >= r13) goto L_0x00ac
            r12 = r0
            java.util.ArrayList<android.support.constraint.solver.widgets.ConstraintWidget> r12 = r12.mChildren
            r13 = r8
            java.lang.Object r12 = r12.get(r13)
            android.support.constraint.solver.widgets.ConstraintWidget r12 = (android.support.constraint.solver.widgets.ConstraintWidget) r12
            r10 = r12
            r12 = r10
            boolean r12 = r12 instanceof android.support.constraint.solver.widgets.WidgetContainer
            if (r12 == 0) goto L_0x0071
            r12 = r10
            android.support.constraint.solver.widgets.WidgetContainer r12 = (android.support.constraint.solver.widgets.WidgetContainer) r12
            r13 = r1
            r14 = r2
            android.support.constraint.solver.widgets.ConstraintWidget r12 = r12.findWidget(r13, r14)
            r11 = r12
            r12 = r11
            if (r12 == 0) goto L_0x006e
            r12 = r11
            r3 = r12
        L_0x006e:
            int r8 = r8 + 1
            goto L_0x004b
        L_0x0071:
            r12 = r10
            int r12 = r12.getDrawX()
            r4 = r12
            r12 = r10
            int r12 = r12.getDrawY()
            r5 = r12
            r12 = r4
            r13 = r10
            int r13 = r13.getWidth()
            int r12 = r12 + r13
            r6 = r12
            r12 = r5
            r13 = r10
            int r13 = r13.getHeight()
            int r12 = r12 + r13
            r7 = r12
            r12 = r1
            r13 = r4
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 < 0) goto L_0x006e
            r12 = r1
            r13 = r6
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 > 0) goto L_0x006e
            r12 = r2
            r13 = r5
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 < 0) goto L_0x006e
            r12 = r2
            r13 = r7
            float r13 = (float) r13
            int r12 = (r12 > r13 ? 1 : (r12 == r13 ? 0 : -1))
            if (r12 > 0) goto L_0x006e
            r12 = r10
            r3 = r12
            goto L_0x006e
        L_0x00ac:
            r12 = r3
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.solver.widgets.WidgetContainer.findWidget(float, float):android.support.constraint.solver.widgets.ConstraintWidget");
    }

    public ArrayList<ConstraintWidget> findWidgets(int i, int i2, int i3, int i4) {
        ArrayList arrayList;
        Rectangle rectangle;
        Rectangle rectangle2;
        int x = i;
        int y = i2;
        int width = i3;
        int height = i4;
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = arrayList2;
        Rectangle rectangle3 = rectangle;
        Rectangle rectangle4 = new Rectangle();
        Rectangle area = rectangle3;
        area.setBounds(x, y, width, height);
        int mChildrenSize = this.mChildren.size();
        for (int i5 = 0; i5 < mChildrenSize; i5++) {
            ConstraintWidget widget = (ConstraintWidget) this.mChildren.get(i5);
            Rectangle rectangle5 = rectangle2;
            Rectangle rectangle6 = new Rectangle();
            Rectangle bounds = rectangle5;
            bounds.setBounds(widget.getDrawX(), widget.getDrawY(), widget.getWidth(), widget.getHeight());
            if (area.intersects(bounds)) {
                boolean add = arrayList4.add(widget);
            }
        }
        return arrayList4;
    }

    public static Rectangle getBounds(ArrayList<ConstraintWidget> arrayList) {
        Rectangle rectangle;
        ArrayList<ConstraintWidget> widgets = arrayList;
        Rectangle rectangle2 = rectangle;
        Rectangle rectangle3 = new Rectangle();
        Rectangle bounds = rectangle2;
        if (widgets.size() == 0) {
            return bounds;
        }
        int minX = Integer.MAX_VALUE;
        int maxX = 0;
        int minY = Integer.MAX_VALUE;
        int maxY = 0;
        int widgetsSize = widgets.size();
        for (int i = 0; i < widgetsSize; i++) {
            ConstraintWidget widget = (ConstraintWidget) widgets.get(i);
            if (widget.getX() < minX) {
                minX = widget.getX();
            }
            if (widget.getY() < minY) {
                minY = widget.getY();
            }
            if (widget.getRight() > maxX) {
                maxX = widget.getRight();
            }
            if (widget.getBottom() > maxY) {
                maxY = widget.getBottom();
            }
        }
        bounds.setBounds(minX, minY, maxX - minX, maxY - minY);
        return bounds;
    }

    public void setOffset(int i, int i2) {
        super.setOffset(i, i2);
        int count = this.mChildren.size();
        for (int i3 = 0; i3 < count; i3++) {
            ((ConstraintWidget) this.mChildren.get(i3)).setOffset(getRootX(), getRootY());
        }
    }

    public void updateDrawPosition() {
        super.updateDrawPosition();
        if (this.mChildren != null) {
            int count = this.mChildren.size();
            for (int i = 0; i < count; i++) {
                ConstraintWidget widget = (ConstraintWidget) this.mChildren.get(i);
                widget.setOffset(getDrawX(), getDrawY());
                if (!(widget instanceof ConstraintWidgetContainer)) {
                    widget.updateDrawPosition();
                }
            }
        }
    }

    public void layout() {
        updateDrawPosition();
        if (this.mChildren != null) {
            int count = this.mChildren.size();
            for (int i = 0; i < count; i++) {
                ConstraintWidget widget = (ConstraintWidget) this.mChildren.get(i);
                if (widget instanceof WidgetContainer) {
                    ((WidgetContainer) widget).layout();
                }
            }
        }
    }

    public void resetSolverVariables(Cache cache) {
        Cache cache2 = cache;
        super.resetSolverVariables(cache2);
        int count = this.mChildren.size();
        for (int i = 0; i < count; i++) {
            ((ConstraintWidget) this.mChildren.get(i)).resetSolverVariables(cache2);
        }
    }

    public void removeAllChildren() {
        this.mChildren.clear();
    }
}
