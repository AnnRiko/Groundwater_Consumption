package android.support.graphics.drawable;

import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;

public interface Animatable2Compat extends Animatable {

    public static abstract class AnimationCallback {
        android.graphics.drawable.Animatable2.AnimationCallback mPlatformCallback;

        public AnimationCallback() {
        }

        public void onAnimationStart(Drawable drawable) {
        }

        public void onAnimationEnd(Drawable drawable) {
        }

        /* access modifiers changed from: 0000 */
        @RequiresApi(23)
        public android.graphics.drawable.Animatable2.AnimationCallback getPlatformCallback() {
            C01591 r5;
            if (this.mPlatformCallback == null) {
                C01591 r2 = r5;
                C01591 r3 = new android.graphics.drawable.Animatable2.AnimationCallback(this) {
                    final /* synthetic */ AnimationCallback this$0;

                    {
                        this.this$0 = r5;
                    }

                    public void onAnimationStart(Drawable drawable) {
                        Drawable drawable2 = drawable;
                        this.this$0.onAnimationStart(drawable2);
                    }

                    public void onAnimationEnd(Drawable drawable) {
                        Drawable drawable2 = drawable;
                        this.this$0.onAnimationEnd(drawable2);
                    }
                };
                this.mPlatformCallback = r2;
            }
            return this.mPlatformCallback;
        }
    }

    void clearAnimationCallbacks();

    void registerAnimationCallback(@NonNull AnimationCallback animationCallback);

    boolean unregisterAnimationCallback(@NonNull AnimationCallback animationCallback);
}
