package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build.VERSION;
import android.support.annotation.AnimatorRes;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.p000v4.content.res.TypedArrayUtils;
import android.support.p000v4.graphics.PathParser;
import android.support.p000v4.graphics.PathParser.PathDataNode;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import java.io.IOException;
import java.util.ArrayList;
import org.shaded.apache.http.HttpStatus;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({Scope.LIBRARY_GROUP})
public class AnimatorInflaterCompat {
    private static final boolean DBG_ANIMATOR_INFLATER = false;
    private static final int MAX_NUM_POINTS = 100;
    private static final String TAG = "AnimatorInflater";
    private static final int TOGETHER = 0;
    private static final int VALUE_TYPE_COLOR = 3;
    private static final int VALUE_TYPE_FLOAT = 0;
    private static final int VALUE_TYPE_INT = 1;
    private static final int VALUE_TYPE_PATH = 2;
    private static final int VALUE_TYPE_UNDEFINED = 4;

    private static class PathDataEvaluator implements TypeEvaluator<PathDataNode[]> {
        private PathDataNode[] mNodeArray;

        PathDataEvaluator() {
        }

        PathDataEvaluator(PathDataNode[] pathDataNodeArr) {
            this.mNodeArray = pathDataNodeArr;
        }

        public PathDataNode[] evaluate(float f, PathDataNode[] pathDataNodeArr, PathDataNode[] pathDataNodeArr2) {
            IllegalArgumentException illegalArgumentException;
            float fraction = f;
            PathDataNode[] startPathData = pathDataNodeArr;
            PathDataNode[] endPathData = pathDataNodeArr2;
            if (!PathParser.canMorph(startPathData, endPathData)) {
                IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
                IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("Can't interpolate between two incompatible pathData");
                throw illegalArgumentException2;
            }
            if (this.mNodeArray == null || !PathParser.canMorph(this.mNodeArray, startPathData)) {
                this.mNodeArray = PathParser.deepCopyNodes(startPathData);
            }
            for (int i = 0; i < startPathData.length; i++) {
                this.mNodeArray[i].interpolatePathDataNode(startPathData[i], endPathData[i], fraction);
            }
            return this.mNodeArray;
        }
    }

    public static Animator loadAnimator(Context context, @AnimatorRes int i) throws NotFoundException {
        Animator objectAnimator;
        Context context2 = context;
        int id = i;
        if (VERSION.SDK_INT >= 24) {
            objectAnimator = AnimatorInflater.loadAnimator(context2, id);
        } else {
            objectAnimator = loadAnimator(context2, context2.getResources(), context2.getTheme(), id);
        }
        return objectAnimator;
    }

    public static Animator loadAnimator(Context context, Resources resources, Theme theme, @AnimatorRes int i) throws NotFoundException {
        return loadAnimator(context, resources, theme, i, 1.0f);
    }

    public static Animator loadAnimator(Context context, Resources resources, Theme theme, @AnimatorRes int i, float f) throws NotFoundException {
        NotFoundException notFoundException;
        StringBuilder sb;
        NotFoundException notFoundException2;
        StringBuilder sb2;
        Context context2 = context;
        Resources resources2 = resources;
        Theme theme2 = theme;
        int id = i;
        float pathErrorScale = f;
        XmlResourceParser parser = null;
        try {
            parser = resources2.getAnimation(id);
            Animator createAnimatorFromXml = createAnimatorFromXml(context2, resources2, theme2, parser, pathErrorScale);
            if (parser != null) {
                parser.close();
            }
            return createAnimatorFromXml;
        } catch (XmlPullParserException e) {
            XmlPullParserException ex = e;
            NotFoundException notFoundException3 = notFoundException2;
            StringBuilder sb3 = sb2;
            StringBuilder sb4 = new StringBuilder();
            NotFoundException notFoundException4 = new NotFoundException(sb3.append("Can't load animation resource ID #0x").append(Integer.toHexString(id)).toString());
            NotFoundException rnf = notFoundException3;
            Throwable initCause = rnf.initCause(ex);
            throw rnf;
        } catch (IOException e2) {
            IOException ex2 = e2;
            NotFoundException notFoundException5 = notFoundException;
            StringBuilder sb5 = sb;
            StringBuilder sb6 = new StringBuilder();
            NotFoundException notFoundException6 = new NotFoundException(sb5.append("Can't load animation resource ID #0x").append(Integer.toHexString(id)).toString());
            NotFoundException rnf2 = notFoundException5;
            Throwable initCause2 = rnf2.initCause(ex2);
            throw rnf2;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (parser != null) {
                parser.close();
            }
            throw th2;
        }
    }

    private static PropertyValuesHolder getPVH(TypedArray typedArray, int i, int i2, int i3, String str) {
        int valueTo;
        int valueFrom;
        int valueTo2;
        float valueTo3;
        float valueFrom2;
        float valueTo4;
        PathDataEvaluator pathDataEvaluator;
        PathDataEvaluator pathDataEvaluator2;
        InflateException inflateException;
        StringBuilder sb;
        TypedArray styledAttributes = typedArray;
        int valueType = i;
        int valueFromId = i2;
        int valueToId = i3;
        String propertyName = str;
        TypedValue tvFrom = styledAttributes.peekValue(valueFromId);
        boolean hasFrom = tvFrom != null;
        int fromType = hasFrom ? tvFrom.type : 0;
        TypedValue tvTo = styledAttributes.peekValue(valueToId);
        boolean hasTo = tvTo != null;
        int toType = hasTo ? tvTo.type : 0;
        if (valueType == 4) {
            if ((!hasFrom || !isColorType(fromType)) && (!hasTo || !isColorType(toType))) {
                valueType = 0;
            } else {
                valueType = 3;
            }
        }
        boolean getFloats = valueType == 0;
        PropertyValuesHolder returnValue = null;
        if (valueType == 2) {
            String fromString = styledAttributes.getString(valueFromId);
            String toString = styledAttributes.getString(valueToId);
            PathDataNode[] nodesFrom = PathParser.createNodesFromPathData(fromString);
            PathDataNode[] nodesTo = PathParser.createNodesFromPathData(toString);
            if (!(nodesFrom == null && nodesTo == null)) {
                if (nodesFrom != null) {
                    PathDataEvaluator pathDataEvaluator3 = pathDataEvaluator2;
                    PathDataEvaluator pathDataEvaluator4 = new PathDataEvaluator();
                    PathDataEvaluator pathDataEvaluator5 = pathDataEvaluator3;
                    if (nodesTo == null) {
                        String str2 = propertyName;
                        PathDataEvaluator pathDataEvaluator6 = pathDataEvaluator5;
                        Object[] objArr = new Object[1];
                        Object[] objArr2 = objArr;
                        objArr[0] = nodesFrom;
                        returnValue = PropertyValuesHolder.ofObject(str2, pathDataEvaluator6, objArr2);
                    } else if (!PathParser.canMorph(nodesFrom, nodesTo)) {
                        InflateException inflateException2 = inflateException;
                        StringBuilder sb2 = sb;
                        StringBuilder sb3 = new StringBuilder();
                        InflateException inflateException3 = new InflateException(sb2.append(" Can't morph from ").append(fromString).append(" to ").append(toString).toString());
                        throw inflateException2;
                    } else {
                        String str3 = propertyName;
                        PathDataEvaluator pathDataEvaluator7 = pathDataEvaluator5;
                        Object[] objArr3 = new Object[2];
                        Object[] objArr4 = objArr3;
                        objArr3[0] = nodesFrom;
                        Object[] objArr5 = objArr4;
                        Object[] objArr6 = objArr5;
                        objArr5[1] = nodesTo;
                        returnValue = PropertyValuesHolder.ofObject(str3, pathDataEvaluator7, objArr6);
                    }
                } else if (nodesTo != null) {
                    PathDataEvaluator pathDataEvaluator8 = pathDataEvaluator;
                    PathDataEvaluator pathDataEvaluator9 = new PathDataEvaluator();
                    PathDataEvaluator pathDataEvaluator10 = pathDataEvaluator8;
                    String str4 = propertyName;
                    PathDataEvaluator pathDataEvaluator11 = pathDataEvaluator10;
                    Object[] objArr7 = new Object[1];
                    Object[] objArr8 = objArr7;
                    objArr7[0] = nodesTo;
                    returnValue = PropertyValuesHolder.ofObject(str4, pathDataEvaluator11, objArr8);
                }
            }
        } else {
            TypeEvaluator evaluator = null;
            if (valueType == 3) {
                evaluator = ArgbEvaluator.getInstance();
            }
            if (getFloats) {
                if (hasFrom) {
                    if (fromType == 5) {
                        valueFrom2 = styledAttributes.getDimension(valueFromId, 0.0f);
                    } else {
                        valueFrom2 = styledAttributes.getFloat(valueFromId, 0.0f);
                    }
                    if (hasTo) {
                        if (toType == 5) {
                            valueTo4 = styledAttributes.getDimension(valueToId, 0.0f);
                        } else {
                            valueTo4 = styledAttributes.getFloat(valueToId, 0.0f);
                        }
                        String str5 = propertyName;
                        float[] fArr = new float[2];
                        float[] fArr2 = fArr;
                        fArr[0] = valueFrom2;
                        float[] fArr3 = fArr2;
                        float[] fArr4 = fArr3;
                        fArr3[1] = valueTo4;
                        returnValue = PropertyValuesHolder.ofFloat(str5, fArr4);
                    } else {
                        String str6 = propertyName;
                        float[] fArr5 = new float[1];
                        float[] fArr6 = fArr5;
                        fArr5[0] = valueFrom2;
                        returnValue = PropertyValuesHolder.ofFloat(str6, fArr6);
                    }
                } else {
                    if (toType == 5) {
                        valueTo3 = styledAttributes.getDimension(valueToId, 0.0f);
                    } else {
                        valueTo3 = styledAttributes.getFloat(valueToId, 0.0f);
                    }
                    String str7 = propertyName;
                    float[] fArr7 = new float[1];
                    float[] fArr8 = fArr7;
                    fArr7[0] = valueTo3;
                    returnValue = PropertyValuesHolder.ofFloat(str7, fArr8);
                }
            } else if (hasFrom) {
                if (fromType == 5) {
                    valueFrom = (int) styledAttributes.getDimension(valueFromId, 0.0f);
                } else if (isColorType(fromType)) {
                    valueFrom = styledAttributes.getColor(valueFromId, 0);
                } else {
                    valueFrom = styledAttributes.getInt(valueFromId, 0);
                }
                if (hasTo) {
                    if (toType == 5) {
                        valueTo2 = (int) styledAttributes.getDimension(valueToId, 0.0f);
                    } else if (isColorType(toType)) {
                        valueTo2 = styledAttributes.getColor(valueToId, 0);
                    } else {
                        valueTo2 = styledAttributes.getInt(valueToId, 0);
                    }
                    String str8 = propertyName;
                    int[] iArr = new int[2];
                    int[] iArr2 = iArr;
                    iArr[0] = valueFrom;
                    int[] iArr3 = iArr2;
                    int[] iArr4 = iArr3;
                    iArr3[1] = valueTo2;
                    returnValue = PropertyValuesHolder.ofInt(str8, iArr4);
                } else {
                    String str9 = propertyName;
                    int[] iArr5 = new int[1];
                    int[] iArr6 = iArr5;
                    iArr5[0] = valueFrom;
                    returnValue = PropertyValuesHolder.ofInt(str9, iArr6);
                }
            } else if (hasTo) {
                if (toType == 5) {
                    valueTo = (int) styledAttributes.getDimension(valueToId, 0.0f);
                } else if (isColorType(toType)) {
                    valueTo = styledAttributes.getColor(valueToId, 0);
                } else {
                    valueTo = styledAttributes.getInt(valueToId, 0);
                }
                String str10 = propertyName;
                int[] iArr7 = new int[1];
                int[] iArr8 = iArr7;
                iArr7[0] = valueTo;
                returnValue = PropertyValuesHolder.ofInt(str10, iArr8);
            }
            if (!(returnValue == null || evaluator == null)) {
                returnValue.setEvaluator(evaluator);
            }
        }
        return returnValue;
    }

    private static void parseAnimatorFromTypeArray(ValueAnimator valueAnimator, TypedArray typedArray, TypedArray typedArray2, float f, XmlPullParser xmlPullParser) {
        ValueAnimator anim = valueAnimator;
        TypedArray arrayAnimator = typedArray;
        TypedArray arrayObjectAnimator = typedArray2;
        float pixelSize = f;
        XmlPullParser parser = xmlPullParser;
        long duration = (long) TypedArrayUtils.getNamedInt(arrayAnimator, parser, "duration", 1, HttpStatus.SC_MULTIPLE_CHOICES);
        long startDelay = (long) TypedArrayUtils.getNamedInt(arrayAnimator, parser, "startOffset", 2, 0);
        int valueType = TypedArrayUtils.getNamedInt(arrayAnimator, parser, "valueType", 7, 4);
        if (TypedArrayUtils.hasAttribute(parser, "valueFrom") && TypedArrayUtils.hasAttribute(parser, "valueTo")) {
            if (valueType == 4) {
                valueType = inferValueTypeFromValues(arrayAnimator, 5, 6);
            }
            PropertyValuesHolder pvh = getPVH(arrayAnimator, valueType, 5, 6, "");
            if (pvh != null) {
                ValueAnimator valueAnimator2 = anim;
                PropertyValuesHolder[] propertyValuesHolderArr = new PropertyValuesHolder[1];
                PropertyValuesHolder[] propertyValuesHolderArr2 = propertyValuesHolderArr;
                propertyValuesHolderArr[0] = pvh;
                valueAnimator2.setValues(propertyValuesHolderArr2);
            }
        }
        ValueAnimator duration2 = anim.setDuration(duration);
        anim.setStartDelay(startDelay);
        anim.setRepeatCount(TypedArrayUtils.getNamedInt(arrayAnimator, parser, "repeatCount", 3, 0));
        anim.setRepeatMode(TypedArrayUtils.getNamedInt(arrayAnimator, parser, "repeatMode", 4, 1));
        if (arrayObjectAnimator != null) {
            setupObjectAnimator(anim, arrayObjectAnimator, valueType, pixelSize, parser);
        }
    }

    private static void setupObjectAnimator(ValueAnimator valueAnimator, TypedArray typedArray, int i, float f, XmlPullParser xmlPullParser) {
        InflateException inflateException;
        StringBuilder sb;
        TypedArray arrayObjectAnimator = typedArray;
        int valueType = i;
        float pixelSize = f;
        XmlPullParser parser = xmlPullParser;
        ObjectAnimator oa = (ObjectAnimator) valueAnimator;
        String pathData = TypedArrayUtils.getNamedString(arrayObjectAnimator, parser, "pathData", 1);
        if (pathData != null) {
            String propertyXName = TypedArrayUtils.getNamedString(arrayObjectAnimator, parser, "propertyXName", 2);
            String propertyYName = TypedArrayUtils.getNamedString(arrayObjectAnimator, parser, "propertyYName", 3);
            if (valueType == 2 || valueType == 4) {
            }
            if (propertyXName == null && propertyYName == null) {
                InflateException inflateException2 = inflateException;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                InflateException inflateException3 = new InflateException(sb2.append(arrayObjectAnimator.getPositionDescription()).append(" propertyXName or propertyYName is needed for PathData").toString());
                throw inflateException2;
            }
            setupPathMotion(PathParser.createPathFromPathData(pathData), oa, 0.5f * pixelSize, propertyXName, propertyYName);
            return;
        }
        oa.setPropertyName(TypedArrayUtils.getNamedString(arrayObjectAnimator, parser, "propertyName", 0));
    }

    private static void setupPathMotion(Path path, ObjectAnimator objectAnimator, float f, String str, String str2) {
        PathMeasure pathMeasure;
        ArrayList arrayList;
        PathMeasure pathMeasure2;
        Path path2 = path;
        ObjectAnimator oa = objectAnimator;
        float precision = f;
        String propertyXName = str;
        String propertyYName = str2;
        PathMeasure pathMeasure3 = pathMeasure;
        PathMeasure pathMeasure4 = new PathMeasure(path2, false);
        PathMeasure measureForTotalLength = pathMeasure3;
        float totalLength = 0.0f;
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = arrayList2;
        boolean add = arrayList4.add(Float.valueOf(0.0f));
        do {
            totalLength += measureForTotalLength.getLength();
            boolean add2 = arrayList4.add(Float.valueOf(totalLength));
        } while (measureForTotalLength.nextContour());
        PathMeasure pathMeasure5 = pathMeasure2;
        PathMeasure pathMeasure6 = new PathMeasure(path2, false);
        PathMeasure pathMeasure7 = pathMeasure5;
        int numPoints = Math.min(100, ((int) (totalLength / precision)) + 1);
        float[] mX = new float[numPoints];
        float[] mY = new float[numPoints];
        float[] position = new float[2];
        int contourIndex = 0;
        float step = totalLength / ((float) (numPoints - 1));
        float currentDistance = 0.0f;
        for (int i = 0; i < numPoints; i++) {
            boolean posTan = pathMeasure7.getPosTan(currentDistance - ((Float) arrayList4.get(contourIndex)).floatValue(), position, null);
            mX[i] = position[0];
            mY[i] = position[1];
            currentDistance += step;
            if (contourIndex + 1 < arrayList4.size() && currentDistance > ((Float) arrayList4.get(contourIndex + 1)).floatValue()) {
                contourIndex++;
                boolean nextContour = pathMeasure7.nextContour();
            }
        }
        PropertyValuesHolder x = null;
        PropertyValuesHolder y = null;
        if (propertyXName != null) {
            x = PropertyValuesHolder.ofFloat(propertyXName, mX);
        }
        if (propertyYName != null) {
            y = PropertyValuesHolder.ofFloat(propertyYName, mY);
        }
        if (x == null) {
            ObjectAnimator objectAnimator2 = oa;
            PropertyValuesHolder[] propertyValuesHolderArr = new PropertyValuesHolder[1];
            PropertyValuesHolder[] propertyValuesHolderArr2 = propertyValuesHolderArr;
            propertyValuesHolderArr[0] = y;
            objectAnimator2.setValues(propertyValuesHolderArr2);
        } else if (y == null) {
            ObjectAnimator objectAnimator3 = oa;
            PropertyValuesHolder[] propertyValuesHolderArr3 = new PropertyValuesHolder[1];
            PropertyValuesHolder[] propertyValuesHolderArr4 = propertyValuesHolderArr3;
            propertyValuesHolderArr3[0] = x;
            objectAnimator3.setValues(propertyValuesHolderArr4);
        } else {
            ObjectAnimator objectAnimator4 = oa;
            PropertyValuesHolder[] propertyValuesHolderArr5 = new PropertyValuesHolder[2];
            PropertyValuesHolder[] propertyValuesHolderArr6 = propertyValuesHolderArr5;
            propertyValuesHolderArr5[0] = x;
            PropertyValuesHolder[] propertyValuesHolderArr7 = propertyValuesHolderArr6;
            PropertyValuesHolder[] propertyValuesHolderArr8 = propertyValuesHolderArr7;
            propertyValuesHolderArr7[1] = y;
            objectAnimator4.setValues(propertyValuesHolderArr8);
        }
    }

    private static Animator createAnimatorFromXml(Context context, Resources resources, Theme theme, XmlPullParser xmlPullParser, float f) throws XmlPullParserException, IOException {
        XmlPullParser parser = xmlPullParser;
        return createAnimatorFromXml(context, resources, theme, parser, Xml.asAttributeSet(parser), null, 0, f);
    }

    /* JADX WARNING: type inference failed for: r10v0 */
    /* JADX WARNING: type inference failed for: r10v2 */
    /* JADX WARNING: type inference failed for: r26v3 */
    /* JADX WARNING: type inference failed for: r18v50 */
    /* JADX WARNING: type inference failed for: r18v59, types: [android.animation.ValueAnimator] */
    /* JADX WARNING: type inference failed for: r10v4 */
    /* JADX WARNING: type inference failed for: r10v5 */
    /* JADX WARNING: type inference failed for: r19v19, types: [java.lang.Object] */
    /* JADX WARNING: type inference failed for: r18v68, types: [android.animation.ObjectAnimator] */
    /* JADX WARNING: type inference failed for: r10v6 */
    /* JADX WARNING: type inference failed for: r10v7 */
    /* JADX WARNING: type inference failed for: r10v8 */
    /* JADX WARNING: type inference failed for: r10v9 */
    /* JADX WARNING: type inference failed for: r10v10 */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0020, code lost:
        r10 = r10;
     */
    /* JADX WARNING: Multi-variable type inference failed. Error: jadx.core.utils.exceptions.JadxRuntimeException: No candidate types for var: r10v2
      assigns: []
      uses: []
      mth insns count: 181
    	at jadx.core.dex.visitors.typeinference.TypeSearch.fillTypeCandidates(TypeSearch.java:237)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.typeinference.TypeSearch.run(TypeSearch.java:53)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runMultiVariableSearch(TypeInferenceVisitor.java:99)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:92)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:27)
    	at jadx.core.dex.visitors.DepthTraversal.lambda$visit$1(DepthTraversal.java:14)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
    	at jadx.core.ProcessClass.process(ProcessClass.java:30)
    	at jadx.core.ProcessClass.lambda$processDependencies$0(ProcessClass.java:49)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1540)
    	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:49)
    	at jadx.core.ProcessClass.process(ProcessClass.java:35)
    	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:311)
    	at jadx.api.JavaClass.decompile(JavaClass.java:62)
    	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:217)
     */
    /* JADX WARNING: Unknown variable types count: 7 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static android.animation.Animator createAnimatorFromXml(android.content.Context r27, android.content.res.Resources r28, android.content.res.Resources.Theme r29, org.xmlpull.v1.XmlPullParser r30, android.util.AttributeSet r31, android.animation.AnimatorSet r32, int r33, float r34) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            r2 = r27
            r3 = r28
            r4 = r29
            r5 = r30
            r6 = r31
            r7 = r32
            r8 = r33
            r9 = r34
            r18 = 0
            r10 = r18
            r18 = 0
            r11 = r18
            r18 = r5
            int r18 = r18.getDepth()
            r13 = r18
        L_0x0020:
            r18 = r5
            int r18 = r18.next()
            r26 = r18
            r18 = r26
            r19 = r26
            r12 = r19
            r19 = 3
            r0 = r18
            r1 = r19
            if (r0 != r1) goto L_0x0044
            r18 = r5
            int r18 = r18.getDepth()
            r19 = r13
            r0 = r18
            r1 = r19
            if (r0 <= r1) goto L_0x0185
        L_0x0044:
            r18 = r12
            r19 = 1
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x0185
            r18 = r12
            r19 = 2
            r0 = r18
            r1 = r19
            if (r0 == r1) goto L_0x0059
            goto L_0x0020
        L_0x0059:
            r18 = r5
            java.lang.String r18 = r18.getName()
            r14 = r18
            r18 = 0
            r15 = r18
            r18 = r14
            java.lang.String r19 = "objectAnimator"
            boolean r18 = r18.equals(r19)
            if (r18 == 0) goto L_0x00a5
            r18 = r2
            r19 = r3
            r20 = r4
            r21 = r6
            r22 = r9
            r23 = r5
            android.animation.ObjectAnimator r18 = loadObjectAnimator(r18, r19, r20, r21, r22, r23)
            r10 = r18
        L_0x0082:
            r18 = r7
            if (r18 == 0) goto L_0x00a3
            r18 = r15
            if (r18 != 0) goto L_0x00a3
            r18 = r11
            if (r18 != 0) goto L_0x009b
            java.util.ArrayList r18 = new java.util.ArrayList
            r26 = r18
            r18 = r26
            r19 = r26
            r19.<init>()
            r11 = r18
        L_0x009b:
            r18 = r11
            r19 = r10
            boolean r18 = r18.add(r19)
        L_0x00a3:
            goto L_0x0020
        L_0x00a5:
            r18 = r14
            java.lang.String r19 = "animator"
            boolean r18 = r18.equals(r19)
            if (r18 == 0) goto L_0x00c5
            r18 = r2
            r19 = r3
            r20 = r4
            r21 = r6
            r22 = 0
            r23 = r9
            r24 = r5
            android.animation.ValueAnimator r18 = loadAnimator(r18, r19, r20, r21, r22, r23, r24)
            r10 = r18
            goto L_0x0082
        L_0x00c5:
            r18 = r14
            java.lang.String r19 = "set"
            boolean r18 = r18.equals(r19)
            if (r18 == 0) goto L_0x0119
            android.animation.AnimatorSet r18 = new android.animation.AnimatorSet
            r26 = r18
            r18 = r26
            r19 = r26
            r19.<init>()
            r10 = r18
            r18 = r3
            r19 = r4
            r20 = r6
            int[] r21 = android.support.graphics.drawable.AndroidResources.STYLEABLE_ANIMATOR_SET
            android.content.res.TypedArray r18 = android.support.p000v4.content.res.TypedArrayUtils.obtainAttributes(r18, r19, r20, r21)
            r16 = r18
            r18 = r16
            r19 = r5
            java.lang.String r20 = "ordering"
            r21 = 0
            r22 = 0
            int r18 = android.support.p000v4.content.res.TypedArrayUtils.getNamedInt(r18, r19, r20, r21, r22)
            r17 = r18
            r18 = r2
            r19 = r3
            r20 = r4
            r21 = r5
            r22 = r6
            r23 = r10
            android.animation.AnimatorSet r23 = (android.animation.AnimatorSet) r23
            r24 = r17
            r25 = r9
            android.animation.Animator r18 = createAnimatorFromXml(r18, r19, r20, r21, r22, r23, r24, r25)
            r18 = r16
            r18.recycle()
            goto L_0x0082
        L_0x0119:
            r18 = r14
            java.lang.String r19 = "propertyValuesHolder"
            boolean r18 = r18.equals(r19)
            if (r18 == 0) goto L_0x0159
            r18 = r2
            r19 = r3
            r20 = r4
            r21 = r5
            r22 = r5
            android.util.AttributeSet r22 = android.util.Xml.asAttributeSet(r22)
            android.animation.PropertyValuesHolder[] r18 = loadValues(r18, r19, r20, r21, r22)
            r16 = r18
            r18 = r16
            if (r18 == 0) goto L_0x0153
            r18 = r10
            if (r18 == 0) goto L_0x0153
            r18 = r10
            r0 = r18
            boolean r0 = r0 instanceof android.animation.ValueAnimator
            r18 = r0
            if (r18 == 0) goto L_0x0153
            r18 = r10
            android.animation.ValueAnimator r18 = (android.animation.ValueAnimator) r18
            r19 = r16
            r18.setValues(r19)
        L_0x0153:
            r18 = 1
            r15 = r18
            goto L_0x0082
        L_0x0159:
            java.lang.RuntimeException r18 = new java.lang.RuntimeException
            r26 = r18
            r18 = r26
            r19 = r26
            java.lang.StringBuilder r20 = new java.lang.StringBuilder
            r26 = r20
            r20 = r26
            r21 = r26
            r21.<init>()
            java.lang.String r21 = "Unknown animator name: "
            java.lang.StringBuilder r20 = r20.append(r21)
            r21 = r5
            java.lang.String r21 = r21.getName()
            java.lang.StringBuilder r20 = r20.append(r21)
            java.lang.String r20 = r20.toString()
            r19.<init>(r20)
            throw r18
        L_0x0185:
            r18 = r7
            if (r18 == 0) goto L_0x01cf
            r18 = r11
            if (r18 == 0) goto L_0x01cf
            r18 = r11
            int r18 = r18.size()
            r0 = r18
            android.animation.Animator[] r0 = new android.animation.Animator[r0]
            r18 = r0
            r14 = r18
            r18 = 0
            r15 = r18
            r18 = r11
            java.util.Iterator r18 = r18.iterator()
            r16 = r18
        L_0x01a7:
            r18 = r16
            boolean r18 = r18.hasNext()
            if (r18 == 0) goto L_0x01c4
            r18 = r16
            java.lang.Object r18 = r18.next()
            android.animation.Animator r18 = (android.animation.Animator) r18
            r17 = r18
            r18 = r14
            r19 = r15
            int r15 = r15 + 1
            r20 = r17
            r18[r19] = r20
            goto L_0x01a7
        L_0x01c4:
            r18 = r8
            if (r18 != 0) goto L_0x01d4
            r18 = r7
            r19 = r14
            r18.playTogether(r19)
        L_0x01cf:
            r18 = r10
            r2 = r18
            return r2
        L_0x01d4:
            r18 = r7
            r19 = r14
            r18.playSequentially(r19)
            goto L_0x01cf
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.AnimatorInflaterCompat.createAnimatorFromXml(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.animation.AnimatorSet, int, float):android.animation.Animator");
    }

    private static PropertyValuesHolder[] loadValues(Context context, Resources resources, Theme theme, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        ArrayList arrayList;
        Context context2 = context;
        Resources res = resources;
        Theme theme2 = theme;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        ArrayList arrayList2 = null;
        while (true) {
            int eventType = parser.getEventType();
            int type = eventType;
            if (eventType == 3 || type == 1) {
                PropertyValuesHolder[] valuesArray = null;
            } else if (type != 2) {
                int next = parser.next();
            } else {
                if (parser.getName().equals("propertyValuesHolder")) {
                    TypedArray a = TypedArrayUtils.obtainAttributes(res, theme2, attrs, AndroidResources.STYLEABLE_PROPERTY_VALUES_HOLDER);
                    String propertyName = TypedArrayUtils.getNamedString(a, parser, "propertyName", 3);
                    int valueType = TypedArrayUtils.getNamedInt(a, parser, "valueType", 2, 4);
                    PropertyValuesHolder pvh = loadPvh(context2, res, theme2, parser, propertyName, valueType);
                    if (pvh == null) {
                        pvh = getPVH(a, valueType, 0, 1, propertyName);
                    }
                    if (pvh != null) {
                        if (arrayList2 == null) {
                            ArrayList arrayList3 = arrayList;
                            ArrayList arrayList4 = new ArrayList();
                            arrayList2 = arrayList3;
                        }
                        boolean add = arrayList2.add(pvh);
                    }
                    a.recycle();
                }
                int next2 = parser.next();
            }
        }
        PropertyValuesHolder[] valuesArray2 = null;
        if (arrayList2 != null) {
            int count = arrayList2.size();
            valuesArray2 = new PropertyValuesHolder[count];
            for (int i = 0; i < count; i++) {
                valuesArray2[i] = (PropertyValuesHolder) arrayList2.get(i);
            }
        }
        return valuesArray2;
    }

    private static int inferValueTypeOfKeyframe(Resources resources, Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        int valueType;
        XmlPullParser parser = xmlPullParser;
        TypedArray a = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_KEYFRAME);
        TypedValue keyframeValue = TypedArrayUtils.peekNamedValue(a, parser, "value", 0);
        if (!(keyframeValue != null) || !isColorType(keyframeValue.type)) {
            valueType = 0;
        } else {
            valueType = 3;
        }
        a.recycle();
        return valueType;
    }

    private static int inferValueTypeFromValues(TypedArray typedArray, int i, int i2) {
        int valueType;
        TypedArray styledAttributes = typedArray;
        int valueToId = i2;
        TypedValue tvFrom = styledAttributes.peekValue(i);
        boolean hasFrom = tvFrom != null;
        int fromType = hasFrom ? tvFrom.type : 0;
        TypedValue tvTo = styledAttributes.peekValue(valueToId);
        boolean hasTo = tvTo != null;
        int toType = hasTo ? tvTo.type : 0;
        if ((!hasFrom || !isColorType(fromType)) && (!hasTo || !isColorType(toType))) {
            valueType = 0;
        } else {
            valueType = 3;
        }
        return valueType;
    }

    private static void dumpKeyframes(Object[] objArr, String str) {
        StringBuilder sb;
        Object[] keyframes = objArr;
        String header = str;
        if (keyframes != null && keyframes.length != 0) {
            int d = Log.d(TAG, header);
            int count = keyframes.length;
            for (int i = 0; i < count; i++) {
                Keyframe keyframe = (Keyframe) keyframes[i];
                String str2 = TAG;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                int d2 = Log.d(str2, sb2.append("Keyframe ").append(i).append(": fraction ").append(keyframe.getFraction() < 0.0f ? "null" : Float.valueOf(keyframe.getFraction())).append(", ").append(", value : ").append(keyframe.hasValue() ? keyframe.getValue() : "null").toString());
            }
        }
    }

    private static PropertyValuesHolder loadPvh(Context context, Resources resources, Theme theme, XmlPullParser xmlPullParser, String str, int i) throws XmlPullParserException, IOException {
        ArrayList arrayList;
        Context context2 = context;
        Resources res = resources;
        Theme theme2 = theme;
        XmlPullParser parser = xmlPullParser;
        String propertyName = str;
        int valueType = i;
        PropertyValuesHolder value = null;
        ArrayList arrayList2 = null;
        while (true) {
            int next = parser.next();
            int type = next;
            if (next != 3 && type != 1) {
                if (parser.getName().equals("keyframe")) {
                    if (valueType == 4) {
                        valueType = inferValueTypeOfKeyframe(res, theme2, Xml.asAttributeSet(parser), parser);
                    }
                    Keyframe keyframe = loadKeyframe(context2, res, theme2, Xml.asAttributeSet(parser), valueType, parser);
                    if (keyframe != null) {
                        if (arrayList2 == null) {
                            ArrayList arrayList3 = arrayList;
                            ArrayList arrayList4 = new ArrayList();
                            arrayList2 = arrayList3;
                        }
                        boolean add = arrayList2.add(keyframe);
                    }
                    int next2 = parser.next();
                }
            }
        }
        if (arrayList2 != null) {
            int size = arrayList2.size();
            int count = size;
            if (size > 0) {
                Keyframe firstKeyframe = (Keyframe) arrayList2.get(0);
                Keyframe lastKeyframe = (Keyframe) arrayList2.get(count - 1);
                float endFraction = lastKeyframe.getFraction();
                if (endFraction < 1.0f) {
                    if (endFraction < 0.0f) {
                        lastKeyframe.setFraction(1.0f);
                    } else {
                        arrayList2.add(arrayList2.size(), createNewKeyframe(lastKeyframe, 1.0f));
                        count++;
                    }
                }
                float startFraction = firstKeyframe.getFraction();
                if (startFraction != 0.0f) {
                    if (startFraction < 0.0f) {
                        firstKeyframe.setFraction(0.0f);
                    } else {
                        arrayList2.add(0, createNewKeyframe(firstKeyframe, 0.0f));
                        count++;
                    }
                }
                Keyframe[] keyframeArray = new Keyframe[count];
                Object[] array = arrayList2.toArray(keyframeArray);
                for (int i2 = 0; i2 < count; i2++) {
                    Keyframe keyframe2 = keyframeArray[i2];
                    if (keyframe2.getFraction() < 0.0f) {
                        if (i2 == 0) {
                            keyframe2.setFraction(0.0f);
                        } else if (i2 == count - 1) {
                            keyframe2.setFraction(1.0f);
                        } else {
                            int startIndex = i2;
                            int endIndex = i2;
                            int j = startIndex + 1;
                            while (j < count - 1 && keyframeArray[j].getFraction() < 0.0f) {
                                endIndex = j;
                                j++;
                            }
                            distributeKeyframes(keyframeArray, keyframeArray[endIndex + 1].getFraction() - keyframeArray[startIndex - 1].getFraction(), startIndex, endIndex);
                        }
                    }
                }
                value = PropertyValuesHolder.ofKeyframe(propertyName, keyframeArray);
                if (valueType == 3) {
                    value.setEvaluator(ArgbEvaluator.getInstance());
                }
            }
        }
        return value;
    }

    private static Keyframe createNewKeyframe(Keyframe keyframe, float f) {
        Keyframe ofObject;
        Keyframe sampleKeyframe = keyframe;
        float fraction = f;
        if (sampleKeyframe.getType() == Float.TYPE) {
            ofObject = Keyframe.ofFloat(fraction);
        } else if (sampleKeyframe.getType() == Integer.TYPE) {
            ofObject = Keyframe.ofInt(fraction);
        } else {
            ofObject = Keyframe.ofObject(fraction);
        }
        return ofObject;
    }

    private static void distributeKeyframes(Keyframe[] keyframeArr, float f, int i, int i2) {
        Keyframe[] keyframes = keyframeArr;
        int startIndex = i;
        int endIndex = i2;
        float increment = f / ((float) ((endIndex - startIndex) + 2));
        for (int i3 = startIndex; i3 <= endIndex; i3++) {
            keyframes[i3].setFraction(keyframes[i3 - 1].getFraction() + increment);
        }
    }

    private static Keyframe loadKeyframe(Context context, Resources resources, Theme theme, AttributeSet attributeSet, int i, XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        Keyframe ofInt;
        Context context2 = context;
        int valueType = i;
        XmlPullParser parser = xmlPullParser;
        TypedArray a = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_KEYFRAME);
        Keyframe keyframe = null;
        float fraction = TypedArrayUtils.getNamedFloat(a, parser, "fraction", 3, -1.0f);
        TypedValue keyframeValue = TypedArrayUtils.peekNamedValue(a, parser, "value", 0);
        boolean hasValue = keyframeValue != null;
        if (valueType == 4) {
            if (!hasValue || !isColorType(keyframeValue.type)) {
                valueType = 0;
            } else {
                valueType = 3;
            }
        }
        if (hasValue) {
            switch (valueType) {
                case 0:
                    keyframe = Keyframe.ofFloat(fraction, TypedArrayUtils.getNamedFloat(a, parser, "value", 0, 0.0f));
                    break;
                case 1:
                case 3:
                    keyframe = Keyframe.ofInt(fraction, TypedArrayUtils.getNamedInt(a, parser, "value", 0, 0));
                    break;
            }
        } else {
            if (valueType == 0) {
                ofInt = Keyframe.ofFloat(fraction);
            } else {
                ofInt = Keyframe.ofInt(fraction);
            }
            keyframe = ofInt;
        }
        int resID = TypedArrayUtils.getNamedResourceId(a, parser, "interpolator", 1, 0);
        if (resID > 0) {
            keyframe.setInterpolator(AnimationUtilsCompat.loadInterpolator(context2, resID));
        }
        a.recycle();
        return keyframe;
    }

    private static ObjectAnimator loadObjectAnimator(Context context, Resources resources, Theme theme, AttributeSet attributeSet, float f, XmlPullParser xmlPullParser) throws NotFoundException {
        ObjectAnimator objectAnimator;
        Context context2 = context;
        Resources res = resources;
        Theme theme2 = theme;
        AttributeSet attrs = attributeSet;
        float pathErrorScale = f;
        XmlPullParser parser = xmlPullParser;
        ObjectAnimator objectAnimator2 = objectAnimator;
        ObjectAnimator objectAnimator3 = new ObjectAnimator();
        ObjectAnimator anim = objectAnimator2;
        ValueAnimator loadAnimator = loadAnimator(context2, res, theme2, attrs, anim, pathErrorScale, parser);
        return anim;
    }

    private static ValueAnimator loadAnimator(Context context, Resources resources, Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f, XmlPullParser xmlPullParser) throws NotFoundException {
        ValueAnimator valueAnimator2;
        Context context2 = context;
        Resources res = resources;
        Theme theme2 = theme;
        AttributeSet attrs = attributeSet;
        ValueAnimator anim = valueAnimator;
        float pathErrorScale = f;
        XmlPullParser parser = xmlPullParser;
        TypedArray arrayAnimator = TypedArrayUtils.obtainAttributes(res, theme2, attrs, AndroidResources.STYLEABLE_ANIMATOR);
        TypedArray arrayObjectAnimator = TypedArrayUtils.obtainAttributes(res, theme2, attrs, AndroidResources.STYLEABLE_PROPERTY_ANIMATOR);
        if (anim == null) {
            ValueAnimator valueAnimator3 = valueAnimator2;
            ValueAnimator valueAnimator4 = new ValueAnimator();
            anim = valueAnimator3;
        }
        parseAnimatorFromTypeArray(anim, arrayAnimator, arrayObjectAnimator, pathErrorScale, parser);
        int resID = TypedArrayUtils.getNamedResourceId(arrayAnimator, parser, "interpolator", 0, 0);
        if (resID > 0) {
            anim.setInterpolator(AnimationUtilsCompat.loadInterpolator(context2, resID));
        }
        arrayAnimator.recycle();
        if (arrayObjectAnimator != null) {
            arrayObjectAnimator.recycle();
        }
        return anim;
    }

    private static boolean isColorType(int i) {
        int type = i;
        return type >= 28 && type <= 31;
    }

    private AnimatorInflaterCompat() {
    }
}
