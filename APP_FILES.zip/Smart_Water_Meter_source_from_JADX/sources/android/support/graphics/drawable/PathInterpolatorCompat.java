package android.support.graphics.drawable;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.p000v4.content.res.TypedArrayUtils;
import android.support.p000v4.graphics.PathParser;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import org.xmlpull.v1.XmlPullParser;

@RestrictTo({Scope.LIBRARY_GROUP})
public class PathInterpolatorCompat implements Interpolator {
    public static final double EPSILON = 1.0E-5d;
    public static final int MAX_NUM_POINTS = 3000;
    private static final float PRECISION = 0.002f;

    /* renamed from: mX */
    private float[] f21mX;

    /* renamed from: mY */
    private float[] f22mY;

    public PathInterpolatorCompat(Context context, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        Context context2 = context;
        this(context2.getResources(), context2.getTheme(), attributeSet, xmlPullParser);
    }

    public PathInterpolatorCompat(Resources resources, Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        XmlPullParser parser = xmlPullParser;
        TypedArray a = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_PATH_INTERPOLATOR);
        parseInterpolatorFromTypeArray(a, parser);
        a.recycle();
    }

    private void parseInterpolatorFromTypeArray(TypedArray typedArray, XmlPullParser xmlPullParser) {
        InflateException inflateException;
        InflateException inflateException2;
        InflateException inflateException3;
        InflateException inflateException4;
        StringBuilder sb;
        TypedArray a = typedArray;
        XmlPullParser parser = xmlPullParser;
        if (TypedArrayUtils.hasAttribute(parser, "pathData")) {
            String pathData = TypedArrayUtils.getNamedString(a, parser, "pathData", 4);
            Path path = PathParser.createPathFromPathData(pathData);
            if (path == null) {
                InflateException inflateException5 = inflateException4;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                InflateException inflateException6 = new InflateException(sb2.append("The path is null, which is created from ").append(pathData).toString());
                throw inflateException5;
            }
            initPath(path);
        } else if (!TypedArrayUtils.hasAttribute(parser, "controlX1")) {
            InflateException inflateException7 = inflateException3;
            InflateException inflateException8 = new InflateException("pathInterpolator requires the controlX1 attribute");
            throw inflateException7;
        } else if (!TypedArrayUtils.hasAttribute(parser, "controlY1")) {
            InflateException inflateException9 = inflateException2;
            InflateException inflateException10 = new InflateException("pathInterpolator requires the controlY1 attribute");
            throw inflateException9;
        } else {
            float x1 = TypedArrayUtils.getNamedFloat(a, parser, "controlX1", 0, 0.0f);
            float y1 = TypedArrayUtils.getNamedFloat(a, parser, "controlY1", 1, 0.0f);
            boolean hasX2 = TypedArrayUtils.hasAttribute(parser, "controlX2");
            if (hasX2 != TypedArrayUtils.hasAttribute(parser, "controlY2")) {
                InflateException inflateException11 = inflateException;
                InflateException inflateException12 = new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
                throw inflateException11;
            } else if (!hasX2) {
                initQuad(x1, y1);
            } else {
                initCubic(x1, y1, TypedArrayUtils.getNamedFloat(a, parser, "controlX2", 2, 0.0f), TypedArrayUtils.getNamedFloat(a, parser, "controlY2", 3, 0.0f));
            }
        }
    }

    private void initQuad(float f, float f2) {
        Path path;
        float controlX = f;
        float controlY = f2;
        Path path2 = path;
        Path path3 = new Path();
        Path path4 = path2;
        path4.moveTo(0.0f, 0.0f);
        path4.quadTo(controlX, controlY, 1.0f, 1.0f);
        initPath(path4);
    }

    private void initCubic(float f, float f2, float f3, float f4) {
        Path path;
        float x1 = f;
        float y1 = f2;
        float x2 = f3;
        float y2 = f4;
        Path path2 = path;
        Path path3 = new Path();
        Path path4 = path2;
        path4.moveTo(0.0f, 0.0f);
        path4.cubicTo(x1, y1, x2, y2, 1.0f, 1.0f);
        initPath(path4);
    }

    private void initPath(Path path) {
        PathMeasure pathMeasure;
        IllegalArgumentException illegalArgumentException;
        StringBuilder sb;
        IllegalArgumentException illegalArgumentException2;
        IllegalArgumentException illegalArgumentException3;
        StringBuilder sb2;
        IllegalArgumentException illegalArgumentException4;
        StringBuilder sb3;
        PathMeasure pathMeasure2 = pathMeasure;
        PathMeasure pathMeasure3 = new PathMeasure(path, false);
        PathMeasure pathMeasure4 = pathMeasure2;
        float pathLength = pathMeasure4.getLength();
        int numPoints = Math.min(MAX_NUM_POINTS, ((int) (pathLength / PRECISION)) + 1);
        if (numPoints <= 0) {
            IllegalArgumentException illegalArgumentException5 = illegalArgumentException4;
            StringBuilder sb4 = sb3;
            StringBuilder sb5 = new StringBuilder();
            IllegalArgumentException illegalArgumentException6 = new IllegalArgumentException(sb4.append("The Path has a invalid length ").append(pathLength).toString());
            throw illegalArgumentException5;
        }
        this.f21mX = new float[numPoints];
        this.f22mY = new float[numPoints];
        float[] position = new float[2];
        for (int i = 0; i < numPoints; i++) {
            boolean posTan = pathMeasure4.getPosTan((((float) i) * pathLength) / ((float) (numPoints - 1)), position, null);
            this.f21mX[i] = position[0];
            this.f22mY[i] = position[1];
        }
        if (((double) Math.abs(this.f21mX[0])) > 1.0E-5d || ((double) Math.abs(this.f22mY[0])) > 1.0E-5d || ((double) Math.abs(this.f21mX[numPoints - 1] - 1.0f)) > 1.0E-5d || ((double) Math.abs(this.f22mY[numPoints - 1] - 1.0f)) > 1.0E-5d) {
            IllegalArgumentException illegalArgumentException7 = illegalArgumentException;
            StringBuilder sb6 = sb;
            StringBuilder sb7 = new StringBuilder();
            IllegalArgumentException illegalArgumentException8 = new IllegalArgumentException(sb6.append("The Path must start at (0,0) and end at (1,1) start: ").append(this.f21mX[0]).append(",").append(this.f22mY[0]).append(" end:").append(this.f21mX[numPoints - 1]).append(",").append(this.f22mY[numPoints - 1]).toString());
            throw illegalArgumentException7;
        }
        float prevX = 0.0f;
        int componentIndex = 0;
        for (int i2 = 0; i2 < numPoints; i2++) {
            int i3 = componentIndex;
            componentIndex++;
            float x = this.f21mX[i3];
            if (x < prevX) {
                IllegalArgumentException illegalArgumentException9 = illegalArgumentException3;
                StringBuilder sb8 = sb2;
                StringBuilder sb9 = new StringBuilder();
                IllegalArgumentException illegalArgumentException10 = new IllegalArgumentException(sb8.append("The Path cannot loop back on itself, x :").append(x).toString());
                throw illegalArgumentException9;
            }
            this.f21mX[i2] = x;
            prevX = x;
        }
        if (pathMeasure4.nextContour()) {
            IllegalArgumentException illegalArgumentException11 = illegalArgumentException2;
            IllegalArgumentException illegalArgumentException12 = new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
            throw illegalArgumentException11;
        }
    }

    public float getInterpolation(float f) {
        float t = f;
        if (t <= 0.0f) {
            return 0.0f;
        }
        if (t >= 1.0f) {
            return 1.0f;
        }
        int startIndex = 0;
        int endIndex = this.f21mX.length - 1;
        while (endIndex - startIndex > 1) {
            int midIndex = (startIndex + endIndex) / 2;
            if (t < this.f21mX[midIndex]) {
                endIndex = midIndex;
            } else {
                startIndex = midIndex;
            }
        }
        float xRange = this.f21mX[endIndex] - this.f21mX[startIndex];
        if (xRange == 0.0f) {
            return this.f22mY[startIndex];
        }
        float fraction = (t - this.f21mX[startIndex]) / xRange;
        float startY = this.f22mY[startIndex];
        return startY + (fraction * (this.f22mY[endIndex] - startY));
    }
}
