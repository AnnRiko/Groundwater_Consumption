package android.support.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.VectorDrawable;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.p000v4.content.res.ComplexColorCompat;
import android.support.p000v4.content.res.ResourcesCompat;
import android.support.p000v4.content.res.TypedArrayUtils;
import android.support.p000v4.graphics.PathParser;
import android.support.p000v4.graphics.PathParser.PathDataNode;
import android.support.p000v4.graphics.drawable.DrawableCompat;
import android.support.p000v4.util.C1558ArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import com.shaded.fasterxml.jackson.core.util.MinimalPrettyPrinter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class VectorDrawableCompat extends VectorDrawableCommon {
    private static final boolean DBG_VECTOR_DRAWABLE = false;
    static final Mode DEFAULT_TINT_MODE = Mode.SRC_IN;
    private static final int LINECAP_BUTT = 0;
    private static final int LINECAP_ROUND = 1;
    private static final int LINECAP_SQUARE = 2;
    private static final int LINEJOIN_BEVEL = 2;
    private static final int LINEJOIN_MITER = 0;
    private static final int LINEJOIN_ROUND = 1;
    static final String LOGTAG = "VectorDrawableCompat";
    private static final int MAX_CACHED_BITMAP_SIZE = 2048;
    private static final String SHAPE_CLIP_PATH = "clip-path";
    private static final String SHAPE_GROUP = "group";
    private static final String SHAPE_PATH = "path";
    private static final String SHAPE_VECTOR = "vector";
    private boolean mAllowCaching = true;
    private ConstantState mCachedConstantStateDelegate;
    private ColorFilter mColorFilter;
    private boolean mMutated;
    private PorterDuffColorFilter mTintFilter;
    private final Rect mTmpBounds;
    private final float[] mTmpFloats = new float[9];
    private final Matrix mTmpMatrix;
    private VectorDrawableCompatState mVectorState;

    private static class VClipPath extends VPath {
        public VClipPath() {
        }

        public VClipPath(VClipPath vClipPath) {
            super(vClipPath);
        }

        public void inflate(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            Resources r = resources;
            AttributeSet attrs = attributeSet;
            Theme theme2 = theme;
            if (TypedArrayUtils.hasAttribute(xmlPullParser, "pathData")) {
                TypedArray a = TypedArrayUtils.obtainAttributes(r, theme2, attrs, AndroidResources.STYLEABLE_VECTOR_DRAWABLE_CLIP_PATH);
                updateStateFromTypedArray(a);
                a.recycle();
            }
        }

        private void updateStateFromTypedArray(TypedArray typedArray) {
            TypedArray a = typedArray;
            String pathName = a.getString(0);
            if (pathName != null) {
                this.mPathName = pathName;
            }
            String pathData = a.getString(1);
            if (pathData != null) {
                this.mNodes = PathParser.createNodesFromPathData(pathData);
            }
        }

        public boolean isClipPath() {
            return true;
        }
    }

    private static class VFullPath extends VPath {
        private static final int FILL_TYPE_WINDING = 0;
        float mFillAlpha = 1.0f;
        ComplexColorCompat mFillColor;
        int mFillRule = 0;
        float mStrokeAlpha = 1.0f;
        ComplexColorCompat mStrokeColor;
        Cap mStrokeLineCap = Cap.BUTT;
        Join mStrokeLineJoin = Join.MITER;
        float mStrokeMiterlimit = 4.0f;
        float mStrokeWidth = 0.0f;
        private int[] mThemeAttrs;
        float mTrimPathEnd = 1.0f;
        float mTrimPathOffset = 0.0f;
        float mTrimPathStart = 0.0f;

        public VFullPath() {
        }

        public VFullPath(VFullPath vFullPath) {
            VFullPath copy = vFullPath;
            super(copy);
            this.mThemeAttrs = copy.mThemeAttrs;
            this.mStrokeColor = copy.mStrokeColor;
            this.mStrokeWidth = copy.mStrokeWidth;
            this.mStrokeAlpha = copy.mStrokeAlpha;
            this.mFillColor = copy.mFillColor;
            this.mFillRule = copy.mFillRule;
            this.mFillAlpha = copy.mFillAlpha;
            this.mTrimPathStart = copy.mTrimPathStart;
            this.mTrimPathEnd = copy.mTrimPathEnd;
            this.mTrimPathOffset = copy.mTrimPathOffset;
            this.mStrokeLineCap = copy.mStrokeLineCap;
            this.mStrokeLineJoin = copy.mStrokeLineJoin;
            this.mStrokeMiterlimit = copy.mStrokeMiterlimit;
        }

        private Cap getStrokeLineCap(int i, Cap cap) {
            Cap defValue = cap;
            switch (i) {
                case 0:
                    return Cap.BUTT;
                case 1:
                    return Cap.ROUND;
                case 2:
                    return Cap.SQUARE;
                default:
                    return defValue;
            }
        }

        private Join getStrokeLineJoin(int i, Join join) {
            Join defValue = join;
            switch (i) {
                case 0:
                    return Join.MITER;
                case 1:
                    return Join.ROUND;
                case 2:
                    return Join.BEVEL;
                default:
                    return defValue;
            }
        }

        public boolean canApplyTheme() {
            return this.mThemeAttrs != null;
        }

        public void inflate(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            Theme theme2 = theme;
            XmlPullParser parser = xmlPullParser;
            TypedArray a = TypedArrayUtils.obtainAttributes(resources, theme2, attributeSet, AndroidResources.STYLEABLE_VECTOR_DRAWABLE_PATH);
            updateStateFromTypedArray(a, parser, theme2);
            a.recycle();
        }

        private void updateStateFromTypedArray(TypedArray typedArray, XmlPullParser xmlPullParser, Theme theme) {
            TypedArray a = typedArray;
            XmlPullParser parser = xmlPullParser;
            Theme theme2 = theme;
            this.mThemeAttrs = null;
            if (TypedArrayUtils.hasAttribute(parser, "pathData")) {
                String pathName = a.getString(0);
                if (pathName != null) {
                    this.mPathName = pathName;
                }
                String pathData = a.getString(2);
                if (pathData != null) {
                    this.mNodes = PathParser.createNodesFromPathData(pathData);
                }
                this.mFillColor = TypedArrayUtils.getNamedComplexColor(a, parser, theme2, "fillColor", 1, 0);
                this.mFillAlpha = TypedArrayUtils.getNamedFloat(a, parser, "fillAlpha", 12, this.mFillAlpha);
                this.mStrokeLineCap = getStrokeLineCap(TypedArrayUtils.getNamedInt(a, parser, "strokeLineCap", 8, -1), this.mStrokeLineCap);
                this.mStrokeLineJoin = getStrokeLineJoin(TypedArrayUtils.getNamedInt(a, parser, "strokeLineJoin", 9, -1), this.mStrokeLineJoin);
                this.mStrokeMiterlimit = TypedArrayUtils.getNamedFloat(a, parser, "strokeMiterLimit", 10, this.mStrokeMiterlimit);
                this.mStrokeColor = TypedArrayUtils.getNamedComplexColor(a, parser, theme2, "strokeColor", 3, 0);
                this.mStrokeAlpha = TypedArrayUtils.getNamedFloat(a, parser, "strokeAlpha", 11, this.mStrokeAlpha);
                this.mStrokeWidth = TypedArrayUtils.getNamedFloat(a, parser, "strokeWidth", 4, this.mStrokeWidth);
                this.mTrimPathEnd = TypedArrayUtils.getNamedFloat(a, parser, "trimPathEnd", 6, this.mTrimPathEnd);
                this.mTrimPathOffset = TypedArrayUtils.getNamedFloat(a, parser, "trimPathOffset", 7, this.mTrimPathOffset);
                this.mTrimPathStart = TypedArrayUtils.getNamedFloat(a, parser, "trimPathStart", 5, this.mTrimPathStart);
                this.mFillRule = TypedArrayUtils.getNamedInt(a, parser, "fillType", 13, this.mFillRule);
            }
        }

        public boolean isStateful() {
            return this.mFillColor.isStateful() || this.mStrokeColor.isStateful();
        }

        public boolean onStateChanged(int[] iArr) {
            int[] stateSet = iArr;
            return this.mFillColor.onStateChanged(stateSet) | this.mStrokeColor.onStateChanged(stateSet);
        }

        public void applyTheme(Theme theme) {
            Theme theme2 = theme;
            if (this.mThemeAttrs == null) {
            }
        }

        /* access modifiers changed from: 0000 */
        @ColorInt
        public int getStrokeColor() {
            return this.mStrokeColor.getColor();
        }

        /* access modifiers changed from: 0000 */
        public void setStrokeColor(int i) {
            int strokeColor = i;
            this.mStrokeColor.setColor(strokeColor);
        }

        /* access modifiers changed from: 0000 */
        public float getStrokeWidth() {
            return this.mStrokeWidth;
        }

        /* access modifiers changed from: 0000 */
        public void setStrokeWidth(float f) {
            float f2 = f;
            this.mStrokeWidth = f2;
        }

        /* access modifiers changed from: 0000 */
        public float getStrokeAlpha() {
            return this.mStrokeAlpha;
        }

        /* access modifiers changed from: 0000 */
        public void setStrokeAlpha(float f) {
            float f2 = f;
            this.mStrokeAlpha = f2;
        }

        /* access modifiers changed from: 0000 */
        @ColorInt
        public int getFillColor() {
            return this.mFillColor.getColor();
        }

        /* access modifiers changed from: 0000 */
        public void setFillColor(int i) {
            int fillColor = i;
            this.mFillColor.setColor(fillColor);
        }

        /* access modifiers changed from: 0000 */
        public float getFillAlpha() {
            return this.mFillAlpha;
        }

        /* access modifiers changed from: 0000 */
        public void setFillAlpha(float f) {
            float f2 = f;
            this.mFillAlpha = f2;
        }

        /* access modifiers changed from: 0000 */
        public float getTrimPathStart() {
            return this.mTrimPathStart;
        }

        /* access modifiers changed from: 0000 */
        public void setTrimPathStart(float f) {
            float f2 = f;
            this.mTrimPathStart = f2;
        }

        /* access modifiers changed from: 0000 */
        public float getTrimPathEnd() {
            return this.mTrimPathEnd;
        }

        /* access modifiers changed from: 0000 */
        public void setTrimPathEnd(float f) {
            float f2 = f;
            this.mTrimPathEnd = f2;
        }

        /* access modifiers changed from: 0000 */
        public float getTrimPathOffset() {
            return this.mTrimPathOffset;
        }

        /* access modifiers changed from: 0000 */
        public void setTrimPathOffset(float f) {
            float f2 = f;
            this.mTrimPathOffset = f2;
        }
    }

    private static class VGroup extends VObject {
        int mChangingConfigurations;
        final ArrayList<VObject> mChildren;
        private String mGroupName;
        final Matrix mLocalMatrix;
        private float mPivotX = 0.0f;
        private float mPivotY = 0.0f;
        float mRotate = 0.0f;
        private float mScaleX = 1.0f;
        private float mScaleY = 1.0f;
        final Matrix mStackedMatrix;
        private int[] mThemeAttrs;
        private float mTranslateX = 0.0f;
        private float mTranslateY = 0.0f;

        /* JADX WARNING: type inference failed for: r12v4 */
        /* JADX WARNING: type inference failed for: r7v41 */
        /* JADX WARNING: type inference failed for: r6v0 */
        /* JADX WARNING: type inference failed for: r6v1 */
        /* JADX WARNING: type inference failed for: r8v42, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r7v45, types: [android.support.graphics.drawable.VectorDrawableCompat$VPath] */
        /* JADX WARNING: type inference failed for: r8v43, types: [android.support.graphics.drawable.VectorDrawableCompat$VPath] */
        /* JADX WARNING: type inference failed for: r9v6, types: [java.lang.Object] */
        /* JADX WARNING: type inference failed for: r12v5 */
        /* JADX WARNING: type inference failed for: r7v50 */
        /* JADX WARNING: type inference failed for: r6v2 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Unknown variable types count: 9 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public VGroup(android.support.graphics.drawable.VectorDrawableCompat.VGroup r14, android.support.p000v4.util.C1558ArrayMap<java.lang.String, java.lang.Object> r15) {
            /*
                r13 = this;
                r0 = r13
                r1 = r14
                r2 = r15
                r7 = r0
                r8 = 0
                r7.<init>(r8)
                r7 = r0
                android.graphics.Matrix r8 = new android.graphics.Matrix
                r12 = r8
                r8 = r12
                r9 = r12
                r9.<init>()
                r7.mStackedMatrix = r8
                r7 = r0
                java.util.ArrayList r8 = new java.util.ArrayList
                r12 = r8
                r8 = r12
                r9 = r12
                r9.<init>()
                r7.mChildren = r8
                r7 = r0
                r8 = 0
                r7.mRotate = r8
                r7 = r0
                r8 = 0
                r7.mPivotX = r8
                r7 = r0
                r8 = 0
                r7.mPivotY = r8
                r7 = r0
                r8 = 1065353216(0x3f800000, float:1.0)
                r7.mScaleX = r8
                r7 = r0
                r8 = 1065353216(0x3f800000, float:1.0)
                r7.mScaleY = r8
                r7 = r0
                r8 = 0
                r7.mTranslateX = r8
                r7 = r0
                r8 = 0
                r7.mTranslateY = r8
                r7 = r0
                android.graphics.Matrix r8 = new android.graphics.Matrix
                r12 = r8
                r8 = r12
                r9 = r12
                r9.<init>()
                r7.mLocalMatrix = r8
                r7 = r0
                r8 = 0
                r7.mGroupName = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mRotate
                r7.mRotate = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mPivotX
                r7.mPivotX = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mPivotY
                r7.mPivotY = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mScaleX
                r7.mScaleX = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mScaleY
                r7.mScaleY = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mTranslateX
                r7.mTranslateX = r8
                r7 = r0
                r8 = r1
                float r8 = r8.mTranslateY
                r7.mTranslateY = r8
                r7 = r0
                r8 = r1
                int[] r8 = r8.mThemeAttrs
                r7.mThemeAttrs = r8
                r7 = r0
                r8 = r1
                java.lang.String r8 = r8.mGroupName
                r7.mGroupName = r8
                r7 = r0
                r8 = r1
                int r8 = r8.mChangingConfigurations
                r7.mChangingConfigurations = r8
                r7 = r0
                java.lang.String r7 = r7.mGroupName
                if (r7 == 0) goto L_0x0095
                r7 = r2
                r8 = r0
                java.lang.String r8 = r8.mGroupName
                r9 = r0
                java.lang.Object r7 = r7.put(r8, r9)
            L_0x0095:
                r7 = r0
                android.graphics.Matrix r7 = r7.mLocalMatrix
                r8 = r1
                android.graphics.Matrix r8 = r8.mLocalMatrix
                r7.set(r8)
                r7 = r1
                java.util.ArrayList<android.support.graphics.drawable.VectorDrawableCompat$VObject> r7 = r7.mChildren
                r3 = r7
                r7 = 0
                r4 = r7
            L_0x00a4:
                r7 = r4
                r8 = r3
                int r8 = r8.size()
                if (r7 >= r8) goto L_0x0116
                r7 = r3
                r8 = r4
                java.lang.Object r7 = r7.get(r8)
                r5 = r7
                r7 = r5
                boolean r7 = r7 instanceof android.support.graphics.drawable.VectorDrawableCompat.VGroup
                if (r7 == 0) goto L_0x00d0
                r7 = r5
                android.support.graphics.drawable.VectorDrawableCompat$VGroup r7 = (android.support.graphics.drawable.VectorDrawableCompat.VGroup) r7
                r6 = r7
                r7 = r0
                java.util.ArrayList<android.support.graphics.drawable.VectorDrawableCompat$VObject> r7 = r7.mChildren
                android.support.graphics.drawable.VectorDrawableCompat$VGroup r8 = new android.support.graphics.drawable.VectorDrawableCompat$VGroup
                r12 = r8
                r8 = r12
                r9 = r12
                r10 = r6
                r11 = r2
                r9.<init>(r10, r11)
                boolean r7 = r7.add(r8)
            L_0x00cd:
                int r4 = r4 + 1
                goto L_0x00a4
            L_0x00d0:
                r7 = r5
                boolean r7 = r7 instanceof android.support.graphics.drawable.VectorDrawableCompat.VFullPath
                if (r7 == 0) goto L_0x00f8
                android.support.graphics.drawable.VectorDrawableCompat$VFullPath r7 = new android.support.graphics.drawable.VectorDrawableCompat$VFullPath
                r12 = r7
                r7 = r12
                r8 = r12
                r9 = r5
                android.support.graphics.drawable.VectorDrawableCompat$VFullPath r9 = (android.support.graphics.drawable.VectorDrawableCompat.VFullPath) r9
                r8.<init>(r9)
                r6 = r7
            L_0x00e1:
                r7 = r0
                java.util.ArrayList<android.support.graphics.drawable.VectorDrawableCompat$VObject> r7 = r7.mChildren
                r8 = r6
                boolean r7 = r7.add(r8)
                r7 = r6
                java.lang.String r7 = r7.mPathName
                if (r7 == 0) goto L_0x00cd
                r7 = r2
                r8 = r6
                java.lang.String r8 = r8.mPathName
                r9 = r6
                java.lang.Object r7 = r7.put(r8, r9)
                goto L_0x00cd
            L_0x00f8:
                r7 = r5
                boolean r7 = r7 instanceof android.support.graphics.drawable.VectorDrawableCompat.VClipPath
                if (r7 == 0) goto L_0x010a
                android.support.graphics.drawable.VectorDrawableCompat$VClipPath r7 = new android.support.graphics.drawable.VectorDrawableCompat$VClipPath
                r12 = r7
                r7 = r12
                r8 = r12
                r9 = r5
                android.support.graphics.drawable.VectorDrawableCompat$VClipPath r9 = (android.support.graphics.drawable.VectorDrawableCompat.VClipPath) r9
                r8.<init>(r9)
                r6 = r7
                goto L_0x00e1
            L_0x010a:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                r12 = r7
                r7 = r12
                r8 = r12
                java.lang.String r9 = "Unknown object in the tree!"
                r8.<init>(r9)
                throw r7
            L_0x0116:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.VectorDrawableCompat.VGroup.<init>(android.support.graphics.drawable.VectorDrawableCompat$VGroup, android.support.v4.util.ArrayMap):void");
        }

        public VGroup() {
            Matrix matrix;
            ArrayList<VObject> arrayList;
            Matrix matrix2;
            super(null);
            Matrix matrix3 = matrix;
            Matrix matrix4 = new Matrix();
            this.mStackedMatrix = matrix3;
            ArrayList<VObject> arrayList2 = arrayList;
            ArrayList<VObject> arrayList3 = new ArrayList<>();
            this.mChildren = arrayList2;
            Matrix matrix5 = matrix2;
            Matrix matrix6 = new Matrix();
            this.mLocalMatrix = matrix5;
            this.mGroupName = null;
        }

        public String getGroupName() {
            return this.mGroupName;
        }

        public Matrix getLocalMatrix() {
            return this.mLocalMatrix;
        }

        public void inflate(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            XmlPullParser parser = xmlPullParser;
            TypedArray a = TypedArrayUtils.obtainAttributes(resources, theme, attributeSet, AndroidResources.STYLEABLE_VECTOR_DRAWABLE_GROUP);
            updateStateFromTypedArray(a, parser);
            a.recycle();
        }

        private void updateStateFromTypedArray(TypedArray typedArray, XmlPullParser xmlPullParser) {
            TypedArray a = typedArray;
            XmlPullParser parser = xmlPullParser;
            this.mThemeAttrs = null;
            this.mRotate = TypedArrayUtils.getNamedFloat(a, parser, "rotation", 5, this.mRotate);
            this.mPivotX = a.getFloat(1, this.mPivotX);
            this.mPivotY = a.getFloat(2, this.mPivotY);
            this.mScaleX = TypedArrayUtils.getNamedFloat(a, parser, "scaleX", 3, this.mScaleX);
            this.mScaleY = TypedArrayUtils.getNamedFloat(a, parser, "scaleY", 4, this.mScaleY);
            this.mTranslateX = TypedArrayUtils.getNamedFloat(a, parser, "translateX", 6, this.mTranslateX);
            this.mTranslateY = TypedArrayUtils.getNamedFloat(a, parser, "translateY", 7, this.mTranslateY);
            String groupName = a.getString(0);
            if (groupName != null) {
                this.mGroupName = groupName;
            }
            updateLocalMatrix();
        }

        private void updateLocalMatrix() {
            this.mLocalMatrix.reset();
            boolean postTranslate = this.mLocalMatrix.postTranslate(-this.mPivotX, -this.mPivotY);
            boolean postScale = this.mLocalMatrix.postScale(this.mScaleX, this.mScaleY);
            boolean postRotate = this.mLocalMatrix.postRotate(this.mRotate, 0.0f, 0.0f);
            boolean postTranslate2 = this.mLocalMatrix.postTranslate(this.mTranslateX + this.mPivotX, this.mTranslateY + this.mPivotY);
        }

        public float getRotation() {
            return this.mRotate;
        }

        public void setRotation(float f) {
            float rotation = f;
            if (rotation != this.mRotate) {
                this.mRotate = rotation;
                updateLocalMatrix();
            }
        }

        public float getPivotX() {
            return this.mPivotX;
        }

        public void setPivotX(float f) {
            float pivotX = f;
            if (pivotX != this.mPivotX) {
                this.mPivotX = pivotX;
                updateLocalMatrix();
            }
        }

        public float getPivotY() {
            return this.mPivotY;
        }

        public void setPivotY(float f) {
            float pivotY = f;
            if (pivotY != this.mPivotY) {
                this.mPivotY = pivotY;
                updateLocalMatrix();
            }
        }

        public float getScaleX() {
            return this.mScaleX;
        }

        public void setScaleX(float f) {
            float scaleX = f;
            if (scaleX != this.mScaleX) {
                this.mScaleX = scaleX;
                updateLocalMatrix();
            }
        }

        public float getScaleY() {
            return this.mScaleY;
        }

        public void setScaleY(float f) {
            float scaleY = f;
            if (scaleY != this.mScaleY) {
                this.mScaleY = scaleY;
                updateLocalMatrix();
            }
        }

        public float getTranslateX() {
            return this.mTranslateX;
        }

        public void setTranslateX(float f) {
            float translateX = f;
            if (translateX != this.mTranslateX) {
                this.mTranslateX = translateX;
                updateLocalMatrix();
            }
        }

        public float getTranslateY() {
            return this.mTranslateY;
        }

        public void setTranslateY(float f) {
            float translateY = f;
            if (translateY != this.mTranslateY) {
                this.mTranslateY = translateY;
                updateLocalMatrix();
            }
        }

        public boolean isStateful() {
            for (int i = 0; i < this.mChildren.size(); i++) {
                if (((VObject) this.mChildren.get(i)).isStateful()) {
                    return true;
                }
            }
            return false;
        }

        public boolean onStateChanged(int[] iArr) {
            int[] stateSet = iArr;
            boolean changed = false;
            for (int i = 0; i < this.mChildren.size(); i++) {
                changed |= ((VObject) this.mChildren.get(i)).onStateChanged(stateSet);
            }
            return changed;
        }
    }

    private static abstract class VObject {
        private VObject() {
        }

        /* synthetic */ VObject(C01661 r4) {
            C01661 r1 = r4;
            this();
        }

        public boolean isStateful() {
            return false;
        }

        public boolean onStateChanged(int[] iArr) {
            int[] iArr2 = iArr;
            return false;
        }
    }

    private static abstract class VPath extends VObject {
        int mChangingConfigurations;
        protected PathDataNode[] mNodes = null;
        String mPathName;

        public VPath() {
            super(null);
        }

        public void printVPath(int i) {
            StringBuilder sb;
            StringBuilder sb2;
            int level = i;
            String indent = "";
            for (int i2 = 0; i2 < level; i2++) {
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                indent = sb3.append(indent).append("    ").toString();
            }
            String str = VectorDrawableCompat.LOGTAG;
            StringBuilder sb5 = sb;
            StringBuilder sb6 = new StringBuilder();
            int v = Log.v(str, sb5.append(indent).append("current path is :").append(this.mPathName).append(" pathData is ").append(nodesToString(this.mNodes)).toString());
        }

        public String nodesToString(PathDataNode[] pathDataNodeArr) {
            StringBuilder sb;
            StringBuilder sb2;
            PathDataNode[] nodes = pathDataNodeArr;
            String result = MinimalPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
            for (int i = 0; i < nodes.length; i++) {
                StringBuilder sb3 = sb;
                StringBuilder sb4 = new StringBuilder();
                result = sb3.append(result).append(nodes[i].mType).append(":").toString();
                float[] params = nodes[i].mParams;
                for (int j = 0; j < params.length; j++) {
                    StringBuilder sb5 = sb2;
                    StringBuilder sb6 = new StringBuilder();
                    result = sb5.append(result).append(params[j]).append(",").toString();
                }
            }
            return result;
        }

        public VPath(VPath vPath) {
            VPath copy = vPath;
            super(null);
            this.mPathName = copy.mPathName;
            this.mChangingConfigurations = copy.mChangingConfigurations;
            this.mNodes = PathParser.deepCopyNodes(copy.mNodes);
        }

        public void toPath(Path path) {
            Path path2 = path;
            path2.reset();
            if (this.mNodes != null) {
                PathDataNode.nodesToPath(this.mNodes, path2);
            }
        }

        public String getPathName() {
            return this.mPathName;
        }

        public boolean canApplyTheme() {
            return false;
        }

        public void applyTheme(Theme t) {
        }

        public boolean isClipPath() {
            return false;
        }

        public PathDataNode[] getPathData() {
            return this.mNodes;
        }

        public void setPathData(PathDataNode[] pathDataNodeArr) {
            PathDataNode[] nodes = pathDataNodeArr;
            if (!PathParser.canMorph(this.mNodes, nodes)) {
                this.mNodes = PathParser.deepCopyNodes(nodes);
                return;
            }
            PathParser.updateNodes(this.mNodes, nodes);
        }
    }

    private static class VPathRenderer {
        private static final Matrix IDENTITY_MATRIX;
        float mBaseHeight = 0.0f;
        float mBaseWidth = 0.0f;
        private int mChangingConfigurations;
        Paint mFillPaint;
        private final Matrix mFinalPathMatrix;
        Boolean mIsStateful = null;
        private final Path mPath;
        private PathMeasure mPathMeasure;
        private final Path mRenderPath;
        int mRootAlpha = 255;
        final VGroup mRootGroup;
        String mRootName = null;
        Paint mStrokePaint;
        final C1558ArrayMap<String, Object> mVGTargetsMap;
        float mViewportHeight = 0.0f;
        float mViewportWidth = 0.0f;

        static {
            Matrix matrix;
            Matrix matrix2 = matrix;
            Matrix matrix3 = new Matrix();
            IDENTITY_MATRIX = matrix2;
        }

        public VPathRenderer() {
            Matrix matrix;
            C1558ArrayMap<String, Object> arrayMap;
            VGroup vGroup;
            Path path;
            Path path2;
            Matrix matrix2 = matrix;
            Matrix matrix3 = new Matrix();
            this.mFinalPathMatrix = matrix2;
            C1558ArrayMap<String, Object> arrayMap2 = arrayMap;
            C1558ArrayMap<String, Object> arrayMap3 = new C1558ArrayMap<>();
            this.mVGTargetsMap = arrayMap2;
            VGroup vGroup2 = vGroup;
            VGroup vGroup3 = new VGroup();
            this.mRootGroup = vGroup2;
            Path path3 = path;
            Path path4 = new Path();
            this.mPath = path3;
            Path path5 = path2;
            Path path6 = new Path();
            this.mRenderPath = path5;
        }

        public void setRootAlpha(int i) {
            int i2 = i;
            this.mRootAlpha = i2;
        }

        public int getRootAlpha() {
            return this.mRootAlpha;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public float getAlpha() {
            return ((float) getRootAlpha()) / 255.0f;
        }

        public VPathRenderer(VPathRenderer vPathRenderer) {
            Matrix matrix;
            C1558ArrayMap<String, Object> arrayMap;
            VGroup vGroup;
            Path path;
            Path path2;
            VPathRenderer copy = vPathRenderer;
            Matrix matrix2 = matrix;
            Matrix matrix3 = new Matrix();
            this.mFinalPathMatrix = matrix2;
            C1558ArrayMap<String, Object> arrayMap2 = arrayMap;
            C1558ArrayMap<String, Object> arrayMap3 = new C1558ArrayMap<>();
            this.mVGTargetsMap = arrayMap2;
            VGroup vGroup2 = vGroup;
            VGroup vGroup3 = new VGroup(copy.mRootGroup, this.mVGTargetsMap);
            this.mRootGroup = vGroup2;
            Path path3 = path;
            Path path4 = new Path(copy.mPath);
            this.mPath = path3;
            Path path5 = path2;
            Path path6 = new Path(copy.mRenderPath);
            this.mRenderPath = path5;
            this.mBaseWidth = copy.mBaseWidth;
            this.mBaseHeight = copy.mBaseHeight;
            this.mViewportWidth = copy.mViewportWidth;
            this.mViewportHeight = copy.mViewportHeight;
            this.mChangingConfigurations = copy.mChangingConfigurations;
            this.mRootAlpha = copy.mRootAlpha;
            this.mRootName = copy.mRootName;
            if (copy.mRootName != null) {
                Object put = this.mVGTargetsMap.put(copy.mRootName, this);
            }
            this.mIsStateful = copy.mIsStateful;
        }

        private void drawGroupTree(VGroup vGroup, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            VGroup currentGroup = vGroup;
            Canvas canvas2 = canvas;
            int w = i;
            int h = i2;
            ColorFilter filter = colorFilter;
            currentGroup.mStackedMatrix.set(matrix);
            boolean preConcat = currentGroup.mStackedMatrix.preConcat(currentGroup.mLocalMatrix);
            int save = canvas2.save();
            for (int i3 = 0; i3 < currentGroup.mChildren.size(); i3++) {
                VObject child = (VObject) currentGroup.mChildren.get(i3);
                if (child instanceof VGroup) {
                    drawGroupTree((VGroup) child, currentGroup.mStackedMatrix, canvas2, w, h, filter);
                } else if (child instanceof VPath) {
                    drawPath(currentGroup, (VPath) child, canvas2, w, h, filter);
                }
            }
            canvas2.restore();
        }

        public void draw(Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            drawGroupTree(this.mRootGroup, IDENTITY_MATRIX, canvas, i, i2, colorFilter);
        }

        private void drawPath(VGroup vGroup, VPath vPath, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            Paint paint;
            Paint paint2;
            PathMeasure pathMeasure;
            VGroup vGroup2 = vGroup;
            VPath vPath2 = vPath;
            Canvas canvas2 = canvas;
            ColorFilter filter = colorFilter;
            float scaleX = ((float) i) / this.mViewportWidth;
            float scaleY = ((float) i2) / this.mViewportHeight;
            float minScale = Math.min(scaleX, scaleY);
            Matrix groupStackedMatrix = vGroup2.mStackedMatrix;
            this.mFinalPathMatrix.set(groupStackedMatrix);
            boolean postScale = this.mFinalPathMatrix.postScale(scaleX, scaleY);
            float matrixScale = getMatrixScale(groupStackedMatrix);
            if (matrixScale != 0.0f) {
                vPath2.toPath(this.mPath);
                Path path = this.mPath;
                this.mRenderPath.reset();
                if (vPath2.isClipPath()) {
                    this.mRenderPath.addPath(path, this.mFinalPathMatrix);
                    boolean clipPath = canvas2.clipPath(this.mRenderPath);
                    return;
                }
                VFullPath fullPath = (VFullPath) vPath2;
                if (!(fullPath.mTrimPathStart == 0.0f && fullPath.mTrimPathEnd == 1.0f)) {
                    float start = (fullPath.mTrimPathStart + fullPath.mTrimPathOffset) % 1.0f;
                    float end = (fullPath.mTrimPathEnd + fullPath.mTrimPathOffset) % 1.0f;
                    if (this.mPathMeasure == null) {
                        PathMeasure pathMeasure2 = pathMeasure;
                        PathMeasure pathMeasure3 = new PathMeasure();
                        this.mPathMeasure = pathMeasure2;
                    }
                    this.mPathMeasure.setPath(this.mPath, false);
                    float len = this.mPathMeasure.getLength();
                    float start2 = start * len;
                    float end2 = end * len;
                    path.reset();
                    if (start2 > end2) {
                        boolean segment = this.mPathMeasure.getSegment(start2, len, path, true);
                        boolean segment2 = this.mPathMeasure.getSegment(0.0f, end2, path, true);
                    } else {
                        boolean segment3 = this.mPathMeasure.getSegment(start2, end2, path, true);
                    }
                    path.rLineTo(0.0f, 0.0f);
                }
                this.mRenderPath.addPath(path, this.mFinalPathMatrix);
                if (fullPath.mFillColor.willDraw()) {
                    ComplexColorCompat fill = fullPath.mFillColor;
                    if (this.mFillPaint == null) {
                        Paint paint3 = paint2;
                        Paint paint4 = new Paint(1);
                        this.mFillPaint = paint3;
                        this.mFillPaint.setStyle(Style.FILL);
                    }
                    Paint fillPaint = this.mFillPaint;
                    if (fill.isGradient()) {
                        Shader shader = fill.getShader();
                        shader.setLocalMatrix(this.mFinalPathMatrix);
                        Shader shader2 = fillPaint.setShader(shader);
                        fillPaint.setAlpha(Math.round(fullPath.mFillAlpha * 255.0f));
                    } else {
                        fillPaint.setColor(VectorDrawableCompat.applyAlpha(fill.getColor(), fullPath.mFillAlpha));
                    }
                    ColorFilter colorFilter2 = fillPaint.setColorFilter(filter);
                    this.mRenderPath.setFillType(fullPath.mFillRule == 0 ? FillType.WINDING : FillType.EVEN_ODD);
                    canvas2.drawPath(this.mRenderPath, fillPaint);
                }
                if (fullPath.mStrokeColor.willDraw()) {
                    ComplexColorCompat strokeColor = fullPath.mStrokeColor;
                    if (this.mStrokePaint == null) {
                        Paint paint5 = paint;
                        Paint paint6 = new Paint(1);
                        this.mStrokePaint = paint5;
                        this.mStrokePaint.setStyle(Style.STROKE);
                    }
                    Paint strokePaint = this.mStrokePaint;
                    if (fullPath.mStrokeLineJoin != null) {
                        strokePaint.setStrokeJoin(fullPath.mStrokeLineJoin);
                    }
                    if (fullPath.mStrokeLineCap != null) {
                        strokePaint.setStrokeCap(fullPath.mStrokeLineCap);
                    }
                    strokePaint.setStrokeMiter(fullPath.mStrokeMiterlimit);
                    if (strokeColor.isGradient()) {
                        Shader shader3 = strokeColor.getShader();
                        shader3.setLocalMatrix(this.mFinalPathMatrix);
                        Shader shader4 = strokePaint.setShader(shader3);
                        strokePaint.setAlpha(Math.round(fullPath.mStrokeAlpha * 255.0f));
                    } else {
                        strokePaint.setColor(VectorDrawableCompat.applyAlpha(strokeColor.getColor(), fullPath.mStrokeAlpha));
                    }
                    ColorFilter colorFilter3 = strokePaint.setColorFilter(filter);
                    strokePaint.setStrokeWidth(fullPath.mStrokeWidth * minScale * matrixScale);
                    canvas2.drawPath(this.mRenderPath, strokePaint);
                }
            }
        }

        private static float cross(float f, float f2, float f3, float f4) {
            return (f * f4) - (f2 * f3);
        }

        private float getMatrixScale(Matrix matrix) {
            float[] unitVectors = {0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(unitVectors);
            float scaleX = (float) Math.hypot((double) unitVectors[0], (double) unitVectors[1]);
            float scaleY = (float) Math.hypot((double) unitVectors[2], (double) unitVectors[3]);
            float crossProduct = cross(unitVectors[0], unitVectors[1], unitVectors[2], unitVectors[3]);
            float maxScale = Math.max(scaleX, scaleY);
            float matrixScale = 0.0f;
            if (maxScale > 0.0f) {
                matrixScale = Math.abs(crossProduct) / maxScale;
            }
            return matrixScale;
        }

        public boolean isStateful() {
            if (this.mIsStateful == null) {
                this.mIsStateful = Boolean.valueOf(this.mRootGroup.isStateful());
            }
            return this.mIsStateful.booleanValue();
        }

        public boolean onStateChanged(int[] iArr) {
            return this.mRootGroup.onStateChanged(iArr);
        }
    }

    private static class VectorDrawableCompatState extends ConstantState {
        boolean mAutoMirrored;
        boolean mCacheDirty;
        boolean mCachedAutoMirrored;
        Bitmap mCachedBitmap;
        int mCachedRootAlpha;
        int[] mCachedThemeAttrs;
        ColorStateList mCachedTint;
        Mode mCachedTintMode;
        int mChangingConfigurations;
        Paint mTempPaint;
        ColorStateList mTint = null;
        Mode mTintMode = VectorDrawableCompat.DEFAULT_TINT_MODE;
        VPathRenderer mVPathRenderer;

        public VectorDrawableCompatState(VectorDrawableCompatState vectorDrawableCompatState) {
            VPathRenderer vPathRenderer;
            Paint paint;
            Paint paint2;
            VectorDrawableCompatState copy = vectorDrawableCompatState;
            if (copy != null) {
                this.mChangingConfigurations = copy.mChangingConfigurations;
                VPathRenderer vPathRenderer2 = vPathRenderer;
                VPathRenderer vPathRenderer3 = new VPathRenderer(copy.mVPathRenderer);
                this.mVPathRenderer = vPathRenderer2;
                if (copy.mVPathRenderer.mFillPaint != null) {
                    VPathRenderer vPathRenderer4 = this.mVPathRenderer;
                    Paint paint3 = paint2;
                    Paint paint4 = new Paint(copy.mVPathRenderer.mFillPaint);
                    vPathRenderer4.mFillPaint = paint3;
                }
                if (copy.mVPathRenderer.mStrokePaint != null) {
                    VPathRenderer vPathRenderer5 = this.mVPathRenderer;
                    Paint paint5 = paint;
                    Paint paint6 = new Paint(copy.mVPathRenderer.mStrokePaint);
                    vPathRenderer5.mStrokePaint = paint5;
                }
                this.mTint = copy.mTint;
                this.mTintMode = copy.mTintMode;
                this.mAutoMirrored = copy.mAutoMirrored;
            }
        }

        public void drawCachedBitmapWithRootAlpha(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.mCachedBitmap, null, rect, getPaint(colorFilter));
        }

        public boolean hasTranslucentRoot() {
            return this.mVPathRenderer.getRootAlpha() < 255;
        }

        public Paint getPaint(ColorFilter colorFilter) {
            Paint paint;
            ColorFilter filter = colorFilter;
            if (!hasTranslucentRoot() && filter == null) {
                return null;
            }
            if (this.mTempPaint == null) {
                Paint paint2 = paint;
                Paint paint3 = new Paint();
                this.mTempPaint = paint2;
                this.mTempPaint.setFilterBitmap(true);
            }
            this.mTempPaint.setAlpha(this.mVPathRenderer.getRootAlpha());
            ColorFilter colorFilter2 = this.mTempPaint.setColorFilter(filter);
            return this.mTempPaint;
        }

        public void updateCachedBitmap(int i, int i2) {
            Canvas canvas;
            int width = i;
            int height = i2;
            this.mCachedBitmap.eraseColor(0);
            Canvas canvas2 = canvas;
            Canvas canvas3 = new Canvas(this.mCachedBitmap);
            this.mVPathRenderer.draw(canvas2, width, height, null);
        }

        public void createCachedBitmapIfNeeded(int i, int i2) {
            int width = i;
            int height = i2;
            if (this.mCachedBitmap == null || !canReuseBitmap(width, height)) {
                this.mCachedBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
                this.mCacheDirty = true;
            }
        }

        public boolean canReuseBitmap(int i, int i2) {
            int height = i2;
            if (i == this.mCachedBitmap.getWidth() && height == this.mCachedBitmap.getHeight()) {
                return true;
            }
            return false;
        }

        public boolean canReuseCache() {
            if (!this.mCacheDirty && this.mCachedTint == this.mTint && this.mCachedTintMode == this.mTintMode && this.mCachedAutoMirrored == this.mAutoMirrored && this.mCachedRootAlpha == this.mVPathRenderer.getRootAlpha()) {
                return true;
            }
            return false;
        }

        public void updateCacheStates() {
            this.mCachedTint = this.mTint;
            this.mCachedTintMode = this.mTintMode;
            this.mCachedRootAlpha = this.mVPathRenderer.getRootAlpha();
            this.mCachedAutoMirrored = this.mAutoMirrored;
            this.mCacheDirty = false;
        }

        public VectorDrawableCompatState() {
            VPathRenderer vPathRenderer;
            VPathRenderer vPathRenderer2 = vPathRenderer;
            VPathRenderer vPathRenderer3 = new VPathRenderer();
            this.mVPathRenderer = vPathRenderer2;
        }

        @NonNull
        public Drawable newDrawable() {
            VectorDrawableCompat vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat(this);
            return vectorDrawableCompat2;
        }

        @NonNull
        public Drawable newDrawable(Resources resources) {
            VectorDrawableCompat vectorDrawableCompat;
            Resources resources2 = resources;
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat(this);
            return vectorDrawableCompat2;
        }

        public int getChangingConfigurations() {
            return this.mChangingConfigurations;
        }

        public boolean isStateful() {
            return this.mVPathRenderer.isStateful();
        }

        public boolean onStateChanged(int[] iArr) {
            boolean changed = this.mVPathRenderer.onStateChanged(iArr);
            this.mCacheDirty |= changed;
            return changed;
        }
    }

    @RequiresApi(24)
    private static class VectorDrawableDelegateState extends ConstantState {
        private final ConstantState mDelegateState;

        public VectorDrawableDelegateState(ConstantState constantState) {
            this.mDelegateState = constantState;
        }

        public Drawable newDrawable() {
            VectorDrawableCompat vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat();
            VectorDrawableCompat drawableCompat = vectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = (VectorDrawable) this.mDelegateState.newDrawable();
            return drawableCompat;
        }

        public Drawable newDrawable(Resources resources) {
            VectorDrawableCompat vectorDrawableCompat;
            Resources res = resources;
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat();
            VectorDrawableCompat drawableCompat = vectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = (VectorDrawable) this.mDelegateState.newDrawable(res);
            return drawableCompat;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            VectorDrawableCompat vectorDrawableCompat;
            Resources res = resources;
            Theme theme2 = theme;
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat();
            VectorDrawableCompat drawableCompat = vectorDrawableCompat2;
            drawableCompat.mDelegateDrawable = (VectorDrawable) this.mDelegateState.newDrawable(res, theme2);
            return drawableCompat;
        }

        public boolean canApplyTheme() {
            return this.mDelegateState.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.mDelegateState.getChangingConfigurations();
        }
    }

    public /* bridge */ /* synthetic */ void applyTheme(Theme theme) {
        super.applyTheme(theme);
    }

    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
        return super.getColorFilter();
    }

    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    public /* bridge */ /* synthetic */ void setColorFilter(int i, Mode mode) {
        super.setColorFilter(i, mode);
    }

    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    VectorDrawableCompat() {
        Matrix matrix;
        Rect rect;
        VectorDrawableCompatState vectorDrawableCompatState;
        Matrix matrix2 = matrix;
        Matrix matrix3 = new Matrix();
        this.mTmpMatrix = matrix2;
        Rect rect2 = rect;
        Rect rect3 = new Rect();
        this.mTmpBounds = rect2;
        VectorDrawableCompatState vectorDrawableCompatState2 = vectorDrawableCompatState;
        VectorDrawableCompatState vectorDrawableCompatState3 = new VectorDrawableCompatState();
        this.mVectorState = vectorDrawableCompatState2;
    }

    VectorDrawableCompat(@NonNull VectorDrawableCompatState vectorDrawableCompatState) {
        Matrix matrix;
        Rect rect;
        VectorDrawableCompatState state = vectorDrawableCompatState;
        Matrix matrix2 = matrix;
        Matrix matrix3 = new Matrix();
        this.mTmpMatrix = matrix2;
        Rect rect2 = rect;
        Rect rect3 = new Rect();
        this.mTmpBounds = rect2;
        this.mVectorState = state;
        this.mTintFilter = updateTintFilter(this.mTintFilter, state.mTint, state.mTintMode);
    }

    public Drawable mutate() {
        VectorDrawableCompatState vectorDrawableCompatState;
        if (this.mDelegateDrawable != null) {
            Drawable mutate = this.mDelegateDrawable.mutate();
            return this;
        }
        if (!this.mMutated && super.mutate() == this) {
            VectorDrawableCompatState vectorDrawableCompatState2 = vectorDrawableCompatState;
            VectorDrawableCompatState vectorDrawableCompatState3 = new VectorDrawableCompatState(this.mVectorState);
            this.mVectorState = vectorDrawableCompatState2;
            this.mMutated = true;
        }
        return this;
    }

    /* access modifiers changed from: 0000 */
    public Object getTargetByName(String str) {
        return this.mVectorState.mVPathRenderer.mVGTargetsMap.get(str);
    }

    public ConstantState getConstantState() {
        VectorDrawableDelegateState vectorDrawableDelegateState;
        if (this.mDelegateDrawable == null || VERSION.SDK_INT < 24) {
            this.mVectorState.mChangingConfigurations = getChangingConfigurations();
            return this.mVectorState;
        }
        VectorDrawableDelegateState vectorDrawableDelegateState2 = vectorDrawableDelegateState;
        VectorDrawableDelegateState vectorDrawableDelegateState3 = new VectorDrawableDelegateState(this.mDelegateDrawable.getConstantState());
        return vectorDrawableDelegateState2;
    }

    public void draw(Canvas canvas) {
        ColorFilter colorFilter;
        Canvas canvas2 = canvas;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.draw(canvas2);
            return;
        }
        copyBounds(this.mTmpBounds);
        if (this.mTmpBounds.width() > 0 && this.mTmpBounds.height() > 0) {
            if (this.mColorFilter == null) {
                colorFilter = this.mTintFilter;
            } else {
                colorFilter = this.mColorFilter;
            }
            ColorFilter colorFilter2 = colorFilter;
            canvas2.getMatrix(this.mTmpMatrix);
            this.mTmpMatrix.getValues(this.mTmpFloats);
            float canvasScaleX = Math.abs(this.mTmpFloats[0]);
            float canvasScaleY = Math.abs(this.mTmpFloats[4]);
            float canvasSkewX = Math.abs(this.mTmpFloats[1]);
            float canvasSkewY = Math.abs(this.mTmpFloats[3]);
            if (!(canvasSkewX == 0.0f && canvasSkewY == 0.0f)) {
                canvasScaleX = 1.0f;
                canvasScaleY = 1.0f;
            }
            int scaledHeight = (int) (((float) this.mTmpBounds.height()) * canvasScaleY);
            int scaledWidth = Math.min(2048, (int) (((float) this.mTmpBounds.width()) * canvasScaleX));
            int scaledHeight2 = Math.min(2048, scaledHeight);
            if (scaledWidth > 0 && scaledHeight2 > 0) {
                int saveCount = canvas2.save();
                canvas2.translate((float) this.mTmpBounds.left, (float) this.mTmpBounds.top);
                if (needMirroring()) {
                    canvas2.translate((float) this.mTmpBounds.width(), 0.0f);
                    canvas2.scale(-1.0f, 1.0f);
                }
                this.mTmpBounds.offsetTo(0, 0);
                this.mVectorState.createCachedBitmapIfNeeded(scaledWidth, scaledHeight2);
                if (!this.mAllowCaching) {
                    this.mVectorState.updateCachedBitmap(scaledWidth, scaledHeight2);
                } else if (!this.mVectorState.canReuseCache()) {
                    this.mVectorState.updateCachedBitmap(scaledWidth, scaledHeight2);
                    this.mVectorState.updateCacheStates();
                }
                this.mVectorState.drawCachedBitmapWithRootAlpha(canvas2, colorFilter2, this.mTmpBounds);
                canvas2.restoreToCount(saveCount);
            }
        }
    }

    public int getAlpha() {
        if (this.mDelegateDrawable != null) {
            return DrawableCompat.getAlpha(this.mDelegateDrawable);
        }
        return this.mVectorState.mVPathRenderer.getRootAlpha();
    }

    public void setAlpha(int i) {
        int alpha = i;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setAlpha(alpha);
        } else if (this.mVectorState.mVPathRenderer.getRootAlpha() != alpha) {
            this.mVectorState.mVPathRenderer.setRootAlpha(alpha);
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        ColorFilter colorFilter2 = colorFilter;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setColorFilter(colorFilter2);
            return;
        }
        this.mColorFilter = colorFilter2;
        invalidateSelf();
    }

    /* access modifiers changed from: 0000 */
    public PorterDuffColorFilter updateTintFilter(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter2;
        PorterDuffColorFilter porterDuffColorFilter3 = porterDuffColorFilter;
        ColorStateList tint = colorStateList;
        Mode tintMode = mode;
        if (tint == null || tintMode == null) {
            return null;
        }
        PorterDuffColorFilter porterDuffColorFilter4 = porterDuffColorFilter2;
        PorterDuffColorFilter porterDuffColorFilter5 = new PorterDuffColorFilter(tint.getColorForState(getState(), 0), tintMode);
        return porterDuffColorFilter4;
    }

    public void setTint(int i) {
        int tint = i;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTint(this.mDelegateDrawable, tint);
        } else {
            setTintList(ColorStateList.valueOf(tint));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        ColorStateList tint = colorStateList;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTintList(this.mDelegateDrawable, tint);
            return;
        }
        VectorDrawableCompatState state = this.mVectorState;
        if (state.mTint != tint) {
            state.mTint = tint;
            this.mTintFilter = updateTintFilter(this.mTintFilter, tint, state.mTintMode);
            invalidateSelf();
        }
    }

    public void setTintMode(Mode mode) {
        Mode tintMode = mode;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setTintMode(this.mDelegateDrawable, tintMode);
            return;
        }
        VectorDrawableCompatState state = this.mVectorState;
        if (state.mTintMode != tintMode) {
            state.mTintMode = tintMode;
            this.mTintFilter = updateTintFilter(this.mTintFilter, state.mTint, tintMode);
            invalidateSelf();
        }
    }

    public boolean isStateful() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.isStateful();
        }
        return super.isStateful() || (this.mVectorState != null && (this.mVectorState.isStateful() || (this.mVectorState.mTint != null && this.mVectorState.mTint.isStateful())));
    }

    /* access modifiers changed from: protected */
    public boolean onStateChange(int[] iArr) {
        int[] stateSet = iArr;
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.setState(stateSet);
        }
        boolean changed = false;
        VectorDrawableCompatState state = this.mVectorState;
        if (!(state.mTint == null || state.mTintMode == null)) {
            this.mTintFilter = updateTintFilter(this.mTintFilter, state.mTint, state.mTintMode);
            invalidateSelf();
            changed = true;
        }
        if (state.isStateful() && state.onStateChanged(stateSet)) {
            invalidateSelf();
            changed = true;
        }
        return changed;
    }

    public int getOpacity() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getOpacity();
        }
        return -3;
    }

    public int getIntrinsicWidth() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getIntrinsicWidth();
        }
        return (int) this.mVectorState.mVPathRenderer.mBaseWidth;
    }

    public int getIntrinsicHeight() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getIntrinsicHeight();
        }
        return (int) this.mVectorState.mVPathRenderer.mBaseHeight;
    }

    public boolean canApplyTheme() {
        if (this.mDelegateDrawable != null) {
            boolean canApplyTheme = DrawableCompat.canApplyTheme(this.mDelegateDrawable);
        }
        return false;
    }

    public boolean isAutoMirrored() {
        if (this.mDelegateDrawable != null) {
            return DrawableCompat.isAutoMirrored(this.mDelegateDrawable);
        }
        return this.mVectorState.mAutoMirrored;
    }

    public void setAutoMirrored(boolean z) {
        boolean mirrored = z;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.setAutoMirrored(this.mDelegateDrawable, mirrored);
            return;
        }
        this.mVectorState.mAutoMirrored = mirrored;
    }

    @RestrictTo({Scope.LIBRARY_GROUP})
    public float getPixelSize() {
        if (this.mVectorState == null || this.mVectorState.mVPathRenderer == null || this.mVectorState.mVPathRenderer.mBaseWidth == 0.0f || this.mVectorState.mVPathRenderer.mBaseHeight == 0.0f || this.mVectorState.mVPathRenderer.mViewportHeight == 0.0f || this.mVectorState.mVPathRenderer.mViewportWidth == 0.0f) {
            return 1.0f;
        }
        float intrinsicWidth = this.mVectorState.mVPathRenderer.mBaseWidth;
        float intrinsicHeight = this.mVectorState.mVPathRenderer.mBaseHeight;
        float viewportWidth = this.mVectorState.mVPathRenderer.mViewportWidth;
        return Math.min(viewportWidth / intrinsicWidth, this.mVectorState.mVPathRenderer.mViewportHeight / intrinsicHeight);
    }

    @Nullable
    public static VectorDrawableCompat create(@NonNull Resources resources, @DrawableRes int i, @Nullable Theme theme) {
        int type;
        XmlPullParserException xmlPullParserException;
        VectorDrawableCompat vectorDrawableCompat;
        VectorDrawableDelegateState vectorDrawableDelegateState;
        Resources res = resources;
        int resId = i;
        Theme theme2 = theme;
        if (VERSION.SDK_INT >= 24) {
            VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
            VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat();
            VectorDrawableCompat drawable = vectorDrawableCompat2;
            drawable.mDelegateDrawable = ResourcesCompat.getDrawable(res, resId, theme2);
            VectorDrawableCompat vectorDrawableCompat4 = drawable;
            VectorDrawableDelegateState vectorDrawableDelegateState2 = vectorDrawableDelegateState;
            VectorDrawableDelegateState vectorDrawableDelegateState3 = new VectorDrawableDelegateState(drawable.mDelegateDrawable.getConstantState());
            vectorDrawableCompat4.mCachedConstantStateDelegate = vectorDrawableDelegateState2;
            return drawable;
        }
        try {
            XmlResourceParser xml = res.getXml(resId);
            AttributeSet attrs = Xml.asAttributeSet(xml);
            while (true) {
                int next = xml.next();
                type = next;
                if (next == 2 || type == 1) {
                }
            }
            if (type == 2) {
                return createFromXmlInner(res, xml, attrs, theme2);
            }
            XmlPullParserException xmlPullParserException2 = xmlPullParserException;
            XmlPullParserException xmlPullParserException3 = new XmlPullParserException("No start tag found");
            throw xmlPullParserException2;
        } catch (XmlPullParserException e) {
            int e2 = Log.e(LOGTAG, "parser error", e);
            return null;
        } catch (IOException e3) {
            int e4 = Log.e(LOGTAG, "parser error", e3);
            return null;
        }
    }

    public static VectorDrawableCompat createFromXmlInner(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        VectorDrawableCompat vectorDrawableCompat;
        Resources r = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        Theme theme2 = theme;
        VectorDrawableCompat vectorDrawableCompat2 = vectorDrawableCompat;
        VectorDrawableCompat vectorDrawableCompat3 = new VectorDrawableCompat();
        VectorDrawableCompat drawable = vectorDrawableCompat2;
        drawable.inflate(r, parser, attrs, theme2);
        return drawable;
    }

    static int applyAlpha(int i, float f) {
        int color = i;
        return (color & 16777215) | (((int) (((float) Color.alpha(color)) * f)) << 24);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        Resources res = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.inflate(res, parser, attrs);
        } else {
            inflate(res, parser, attrs, null);
        }
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        VPathRenderer vPathRenderer;
        Resources res = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        Theme theme2 = theme;
        if (this.mDelegateDrawable != null) {
            DrawableCompat.inflate(this.mDelegateDrawable, res, parser, attrs, theme2);
            return;
        }
        VectorDrawableCompatState state = this.mVectorState;
        VPathRenderer vPathRenderer2 = vPathRenderer;
        VPathRenderer vPathRenderer3 = new VPathRenderer();
        state.mVPathRenderer = vPathRenderer2;
        TypedArray a = TypedArrayUtils.obtainAttributes(res, theme2, attrs, AndroidResources.STYLEABLE_VECTOR_DRAWABLE_TYPE_ARRAY);
        updateStateFromTypedArray(a, parser);
        a.recycle();
        state.mChangingConfigurations = getChangingConfigurations();
        state.mCacheDirty = true;
        inflateInternal(res, parser, attrs, theme2);
        this.mTintFilter = updateTintFilter(this.mTintFilter, state.mTint, state.mTintMode);
    }

    private static Mode parseTintModeCompat(int i, Mode mode) {
        Mode defaultMode = mode;
        switch (i) {
            case 3:
                return Mode.SRC_OVER;
            case 5:
                return Mode.SRC_IN;
            case 9:
                return Mode.SRC_ATOP;
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            case 16:
                return Mode.ADD;
            default:
                return defaultMode;
        }
    }

    private void updateStateFromTypedArray(TypedArray typedArray, XmlPullParser xmlPullParser) throws XmlPullParserException {
        XmlPullParserException xmlPullParserException;
        StringBuilder sb;
        XmlPullParserException xmlPullParserException2;
        StringBuilder sb2;
        XmlPullParserException xmlPullParserException3;
        StringBuilder sb3;
        XmlPullParserException xmlPullParserException4;
        StringBuilder sb4;
        TypedArray a = typedArray;
        XmlPullParser parser = xmlPullParser;
        VectorDrawableCompatState state = this.mVectorState;
        VPathRenderer pathRenderer = state.mVPathRenderer;
        VectorDrawableCompatState vectorDrawableCompatState = state;
        vectorDrawableCompatState.mTintMode = parseTintModeCompat(TypedArrayUtils.getNamedInt(a, parser, "tintMode", 6, -1), Mode.SRC_IN);
        ColorStateList tint = a.getColorStateList(1);
        if (tint != null) {
            state.mTint = tint;
        }
        state.mAutoMirrored = TypedArrayUtils.getNamedBoolean(a, parser, "autoMirrored", 5, state.mAutoMirrored);
        pathRenderer.mViewportWidth = TypedArrayUtils.getNamedFloat(a, parser, "viewportWidth", 7, pathRenderer.mViewportWidth);
        pathRenderer.mViewportHeight = TypedArrayUtils.getNamedFloat(a, parser, "viewportHeight", 8, pathRenderer.mViewportHeight);
        if (pathRenderer.mViewportWidth <= 0.0f) {
            XmlPullParserException xmlPullParserException5 = xmlPullParserException4;
            StringBuilder sb5 = sb4;
            StringBuilder sb6 = new StringBuilder();
            XmlPullParserException xmlPullParserException6 = new XmlPullParserException(sb5.append(a.getPositionDescription()).append("<vector> tag requires viewportWidth > 0").toString());
            throw xmlPullParserException5;
        } else if (pathRenderer.mViewportHeight <= 0.0f) {
            XmlPullParserException xmlPullParserException7 = xmlPullParserException3;
            StringBuilder sb7 = sb3;
            StringBuilder sb8 = new StringBuilder();
            XmlPullParserException xmlPullParserException8 = new XmlPullParserException(sb7.append(a.getPositionDescription()).append("<vector> tag requires viewportHeight > 0").toString());
            throw xmlPullParserException7;
        } else {
            pathRenderer.mBaseWidth = a.getDimension(3, pathRenderer.mBaseWidth);
            pathRenderer.mBaseHeight = a.getDimension(2, pathRenderer.mBaseHeight);
            if (pathRenderer.mBaseWidth <= 0.0f) {
                XmlPullParserException xmlPullParserException9 = xmlPullParserException2;
                StringBuilder sb9 = sb2;
                StringBuilder sb10 = new StringBuilder();
                XmlPullParserException xmlPullParserException10 = new XmlPullParserException(sb9.append(a.getPositionDescription()).append("<vector> tag requires width > 0").toString());
                throw xmlPullParserException9;
            } else if (pathRenderer.mBaseHeight <= 0.0f) {
                XmlPullParserException xmlPullParserException11 = xmlPullParserException;
                StringBuilder sb11 = sb;
                StringBuilder sb12 = new StringBuilder();
                XmlPullParserException xmlPullParserException12 = new XmlPullParserException(sb11.append(a.getPositionDescription()).append("<vector> tag requires height > 0").toString());
                throw xmlPullParserException11;
            } else {
                pathRenderer.setAlpha(TypedArrayUtils.getNamedFloat(a, parser, "alpha", 4, pathRenderer.getAlpha()));
                String name = a.getString(0);
                if (name != null) {
                    pathRenderer.mRootName = name;
                    Object put = pathRenderer.mVGTargetsMap.put(name, pathRenderer);
                }
            }
        }
    }

    private void inflateInternal(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) throws XmlPullParserException, IOException {
        ArrayDeque arrayDeque;
        XmlPullParserException xmlPullParserException;
        VGroup vGroup;
        VClipPath vClipPath;
        VFullPath vFullPath;
        Resources res = resources;
        XmlPullParser parser = xmlPullParser;
        AttributeSet attrs = attributeSet;
        Theme theme2 = theme;
        VectorDrawableCompatState state = this.mVectorState;
        VPathRenderer pathRenderer = state.mVPathRenderer;
        boolean noPathTag = true;
        ArrayDeque arrayDeque2 = arrayDeque;
        ArrayDeque arrayDeque3 = new ArrayDeque();
        ArrayDeque arrayDeque4 = arrayDeque2;
        arrayDeque4.push(pathRenderer.mRootGroup);
        int eventType = parser.getEventType();
        int innerDepth = parser.getDepth() + 1;
        while (eventType != 1 && (parser.getDepth() >= innerDepth || eventType != 3)) {
            if (eventType == 2) {
                String tagName = parser.getName();
                VGroup currentGroup = (VGroup) arrayDeque4.peek();
                if ("path".equals(tagName)) {
                    VFullPath vFullPath2 = vFullPath;
                    VFullPath vFullPath3 = new VFullPath();
                    VFullPath path = vFullPath2;
                    path.inflate(res, attrs, theme2, parser);
                    boolean add = currentGroup.mChildren.add(path);
                    if (path.getPathName() != null) {
                        Object put = pathRenderer.mVGTargetsMap.put(path.getPathName(), path);
                    }
                    noPathTag = false;
                    VectorDrawableCompatState vectorDrawableCompatState = state;
                    vectorDrawableCompatState.mChangingConfigurations |= path.mChangingConfigurations;
                } else if (SHAPE_CLIP_PATH.equals(tagName)) {
                    VClipPath vClipPath2 = vClipPath;
                    VClipPath vClipPath3 = new VClipPath();
                    VClipPath path2 = vClipPath2;
                    path2.inflate(res, attrs, theme2, parser);
                    boolean add2 = currentGroup.mChildren.add(path2);
                    if (path2.getPathName() != null) {
                        Object put2 = pathRenderer.mVGTargetsMap.put(path2.getPathName(), path2);
                    }
                    VectorDrawableCompatState vectorDrawableCompatState2 = state;
                    vectorDrawableCompatState2.mChangingConfigurations |= path2.mChangingConfigurations;
                } else if (SHAPE_GROUP.equals(tagName)) {
                    VGroup vGroup2 = vGroup;
                    VGroup vGroup3 = new VGroup();
                    VGroup newChildGroup = vGroup2;
                    newChildGroup.inflate(res, attrs, theme2, parser);
                    boolean add3 = currentGroup.mChildren.add(newChildGroup);
                    arrayDeque4.push(newChildGroup);
                    if (newChildGroup.getGroupName() != null) {
                        Object put3 = pathRenderer.mVGTargetsMap.put(newChildGroup.getGroupName(), newChildGroup);
                    }
                    VectorDrawableCompatState vectorDrawableCompatState3 = state;
                    vectorDrawableCompatState3.mChangingConfigurations |= newChildGroup.mChangingConfigurations;
                }
            } else if (eventType == 3) {
                if (SHAPE_GROUP.equals(parser.getName())) {
                    Object pop = arrayDeque4.pop();
                }
            }
            eventType = parser.next();
        }
        if (noPathTag) {
            XmlPullParserException xmlPullParserException2 = xmlPullParserException;
            XmlPullParserException xmlPullParserException3 = new XmlPullParserException("no path defined");
            throw xmlPullParserException2;
        }
    }

    private void printGroupTree(VGroup vGroup, int i) {
        StringBuilder sb;
        StringBuilder sb2;
        StringBuilder sb3;
        VGroup currentGroup = vGroup;
        int level = i;
        String indent = "";
        for (int i2 = 0; i2 < level; i2++) {
            StringBuilder sb4 = sb3;
            StringBuilder sb5 = new StringBuilder();
            indent = sb4.append(indent).append("    ").toString();
        }
        String str = LOGTAG;
        StringBuilder sb6 = sb;
        StringBuilder sb7 = new StringBuilder();
        int v = Log.v(str, sb6.append(indent).append("current group is :").append(currentGroup.getGroupName()).append(" rotation is ").append(currentGroup.mRotate).toString());
        String str2 = LOGTAG;
        StringBuilder sb8 = sb2;
        StringBuilder sb9 = new StringBuilder();
        int v2 = Log.v(str2, sb8.append(indent).append("matrix is :").append(currentGroup.getLocalMatrix().toString()).toString());
        for (int i3 = 0; i3 < currentGroup.mChildren.size(); i3++) {
            VObject child = (VObject) currentGroup.mChildren.get(i3);
            if (child instanceof VGroup) {
                printGroupTree((VGroup) child, level + 1);
            } else {
                ((VPath) child).printVPath(level + 1);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    public void setAllowCaching(boolean z) {
        boolean z2 = z;
        this.mAllowCaching = z2;
    }

    private boolean needMirroring() {
        if (VERSION.SDK_INT < 17) {
            return false;
        }
        return isAutoMirrored() && DrawableCompat.getLayoutDirection(this) == 1;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        Rect bounds = rect;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.setBounds(bounds);
        }
    }

    public int getChangingConfigurations() {
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.mVectorState.getChangingConfigurations();
    }

    public void invalidateSelf() {
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    public void scheduleSelf(Runnable runnable, long j) {
        Runnable what = runnable;
        long when = j;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.scheduleSelf(what, when);
        } else {
            super.scheduleSelf(what, when);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = z;
        boolean restart = z2;
        if (this.mDelegateDrawable != null) {
            return this.mDelegateDrawable.setVisible(visible, restart);
        }
        return super.setVisible(visible, restart);
    }

    public void unscheduleSelf(Runnable runnable) {
        Runnable what = runnable;
        if (this.mDelegateDrawable != null) {
            this.mDelegateDrawable.unscheduleSelf(what);
        } else {
            super.unscheduleSelf(what);
        }
    }
}
