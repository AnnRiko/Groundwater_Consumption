package android.support.v13.view;

import android.graphics.Point;
import android.support.p000v4.view.MotionEventCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;

public class DragStartHelper {
    private boolean mDragging;
    private int mLastTouchX;
    private int mLastTouchY;
    private final OnDragStartListener mListener;
    private final OnLongClickListener mLongClickListener;
    private final OnTouchListener mTouchListener;
    private final View mView;

    public interface OnDragStartListener {
        boolean onDragStart(View view, DragStartHelper dragStartHelper);
    }

    public DragStartHelper(View view, OnDragStartListener onDragStartListener) {
        C02301 r7;
        C02312 r72;
        View view2 = view;
        OnDragStartListener listener = onDragStartListener;
        C02301 r4 = r7;
        C02301 r5 = new OnLongClickListener(this) {
            final /* synthetic */ DragStartHelper this$0;

            {
                this.this$0 = r5;
            }

            public boolean onLongClick(View view) {
                return this.this$0.onLongClick(view);
            }
        };
        this.mLongClickListener = r4;
        C02312 r42 = r72;
        C02312 r52 = new OnTouchListener(this) {
            final /* synthetic */ DragStartHelper this$0;

            {
                this.this$0 = r5;
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                return this.this$0.onTouch(view, motionEvent);
            }
        };
        this.mTouchListener = r42;
        this.mView = view2;
        this.mListener = listener;
    }

    public void attach() {
        this.mView.setOnLongClickListener(this.mLongClickListener);
        this.mView.setOnTouchListener(this.mTouchListener);
    }

    public void detach() {
        this.mView.setOnLongClickListener(null);
        this.mView.setOnTouchListener(null);
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        View v = view;
        MotionEvent event = motionEvent;
        int x = (int) event.getX();
        int y = (int) event.getY();
        switch (event.getAction()) {
            case 0:
                this.mLastTouchX = x;
                this.mLastTouchY = y;
                break;
            case 1:
            case 3:
                this.mDragging = false;
                break;
            case 2:
                if (MotionEventCompat.isFromSource(event, 8194) && (event.getButtonState() & 1) != 0 && !this.mDragging && !(this.mLastTouchX == x && this.mLastTouchY == y)) {
                    this.mLastTouchX = x;
                    this.mLastTouchY = y;
                    this.mDragging = this.mListener.onDragStart(v, this);
                    return this.mDragging;
                }
        }
        return false;
    }

    public boolean onLongClick(View view) {
        return this.mListener.onDragStart(view, this);
    }

    public void getTouchPosition(Point point) {
        point.set(this.mLastTouchX, this.mLastTouchY);
    }
}
