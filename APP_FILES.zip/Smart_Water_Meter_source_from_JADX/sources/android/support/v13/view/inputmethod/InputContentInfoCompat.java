package android.support.v13.view.inputmethod;

import android.content.ClipDescription;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.view.inputmethod.InputContentInfo;

public final class InputContentInfoCompat {
    private final InputContentInfoCompatImpl mImpl;

    @RequiresApi(25)
    private static final class InputContentInfoCompatApi25Impl implements InputContentInfoCompatImpl {
        @NonNull
        final InputContentInfo mObject;

        InputContentInfoCompatApi25Impl(@NonNull Object obj) {
            this.mObject = (InputContentInfo) obj;
        }

        InputContentInfoCompatApi25Impl(@NonNull Uri uri, @NonNull ClipDescription clipDescription, @Nullable Uri uri2) {
            InputContentInfo inputContentInfo;
            InputContentInfo inputContentInfo2 = inputContentInfo;
            InputContentInfo inputContentInfo3 = new InputContentInfo(uri, clipDescription, uri2);
            this.mObject = inputContentInfo2;
        }

        @NonNull
        public Uri getContentUri() {
            return this.mObject.getContentUri();
        }

        @NonNull
        public ClipDescription getDescription() {
            return this.mObject.getDescription();
        }

        @Nullable
        public Uri getLinkUri() {
            return this.mObject.getLinkUri();
        }

        @Nullable
        public Object getInputContentInfo() {
            return this.mObject;
        }

        public void requestPermission() {
            this.mObject.requestPermission();
        }

        public void releasePermission() {
            this.mObject.releasePermission();
        }
    }

    private static final class InputContentInfoCompatBaseImpl implements InputContentInfoCompatImpl {
        @NonNull
        private final Uri mContentUri;
        @NonNull
        private final ClipDescription mDescription;
        @Nullable
        private final Uri mLinkUri;

        InputContentInfoCompatBaseImpl(@NonNull Uri uri, @NonNull ClipDescription clipDescription, @Nullable Uri uri2) {
            ClipDescription description = clipDescription;
            Uri linkUri = uri2;
            this.mContentUri = uri;
            this.mDescription = description;
            this.mLinkUri = linkUri;
        }

        @NonNull
        public Uri getContentUri() {
            return this.mContentUri;
        }

        @NonNull
        public ClipDescription getDescription() {
            return this.mDescription;
        }

        @Nullable
        public Uri getLinkUri() {
            return this.mLinkUri;
        }

        @Nullable
        public Object getInputContentInfo() {
            return null;
        }

        public void requestPermission() {
        }

        public void releasePermission() {
        }
    }

    private interface InputContentInfoCompatImpl {
        @NonNull
        Uri getContentUri();

        @NonNull
        ClipDescription getDescription();

        @Nullable
        Object getInputContentInfo();

        @Nullable
        Uri getLinkUri();

        void releasePermission();

        void requestPermission();
    }

    public InputContentInfoCompat(@NonNull Uri uri, @NonNull ClipDescription clipDescription, @Nullable Uri uri2) {
        InputContentInfoCompatBaseImpl inputContentInfoCompatBaseImpl;
        InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl;
        Uri contentUri = uri;
        ClipDescription description = clipDescription;
        Uri linkUri = uri2;
        if (VERSION.SDK_INT >= 25) {
            InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl2 = inputContentInfoCompatApi25Impl;
            InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl3 = new InputContentInfoCompatApi25Impl(contentUri, description, linkUri);
            this.mImpl = inputContentInfoCompatApi25Impl2;
            return;
        }
        InputContentInfoCompatBaseImpl inputContentInfoCompatBaseImpl2 = inputContentInfoCompatBaseImpl;
        InputContentInfoCompatBaseImpl inputContentInfoCompatBaseImpl3 = new InputContentInfoCompatBaseImpl(contentUri, description, linkUri);
        this.mImpl = inputContentInfoCompatBaseImpl2;
    }

    private InputContentInfoCompat(@NonNull InputContentInfoCompatImpl inputContentInfoCompatImpl) {
        this.mImpl = inputContentInfoCompatImpl;
    }

    @NonNull
    public Uri getContentUri() {
        return this.mImpl.getContentUri();
    }

    @NonNull
    public ClipDescription getDescription() {
        return this.mImpl.getDescription();
    }

    @Nullable
    public Uri getLinkUri() {
        return this.mImpl.getLinkUri();
    }

    @Nullable
    public static InputContentInfoCompat wrap(@Nullable Object obj) {
        InputContentInfoCompat inputContentInfoCompat;
        InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl;
        Object inputContentInfo = obj;
        if (inputContentInfo == null) {
            return null;
        }
        if (VERSION.SDK_INT < 25) {
            return null;
        }
        InputContentInfoCompat inputContentInfoCompat2 = inputContentInfoCompat;
        InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl2 = inputContentInfoCompatApi25Impl;
        InputContentInfoCompatApi25Impl inputContentInfoCompatApi25Impl3 = new InputContentInfoCompatApi25Impl(inputContentInfo);
        InputContentInfoCompat inputContentInfoCompat3 = new InputContentInfoCompat(inputContentInfoCompatApi25Impl2);
        return inputContentInfoCompat2;
    }

    @Nullable
    public Object unwrap() {
        return this.mImpl.getInputContentInfo();
    }

    public void requestPermission() {
        this.mImpl.requestPermission();
    }

    public void releasePermission() {
        this.mImpl.releasePermission();
    }
}
